#!/usr/bin/env python3
"""Scientific regression tests and optional actual-artifact consistency checks."""
import copy
import inspect
import json
import math
import os
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

import analyze_october_field_session as legacy
import rebuild_oct18_single_car as r
import diagnose_oct18_rebuild as d


def fixture_config():
    return {'anchors_xyz_m':{'a':[0.,0.,2.2],'b':[5.,0.,2.2]},
        'antenna_height_m':.2, 'base_to_antenna_body_xy_m':[.12,-.08],
        'candidate_start_antenna_xyz_m':[2.,2.,.2], 'initial_heading_deg':90.,
        'graph_parameters':{'keyframe_step_s':1.,'range_bin_half_width_s':.4},
        'bin_min_valid_observations':5,
        'filter':{'half_window_s':.5,'min_other_valid_neighbors':10,'mad_multiplier':4.5,
                  'mad_scale':1.4826,'absolute_floor_m':.35,'vertical_feasibility_tolerance_m':.05},
        'evaluation':{'endpoints_xyz_m':{'x':[3.,3.,.2]}}}


def fixture_data(values, times=None):
    if times is None:
        times = np.arange(len(values))*.02
    return {'uwb':[{'header_s':float(t),'receive_s':float(t)+.04,
        'ranges':{'a':[float(v)],'b':[float(v)]}} for t,v in zip(times,values)],
        'phases':[{'phase':'test','start_s':-1.,'end_s':100.}]}


class RebuildModelTests(unittest.TestCase):
    def test_rotating_lever_and_inverse_start(self):
        poses = np.asarray([[0.,0.,0.],[0.,0.,math.pi/2],[0.,0.,math.pi]])
        np.testing.assert_allclose(r.antenna(poses,[.12,-.08]),
            [[.12,-.08],[.08,.12],[-.12,.08]],atol=1e-14)
        local = np.asarray([[4.,7.,.3],[4.,8.,.2]])
        base,start = r.initial_base(local,[2.,2.,.2],math.pi/2,[.12,-.08])
        np.testing.assert_allclose(start,[1.92,1.88],atol=1e-14)
        np.testing.assert_allclose(r.antenna(base,[.12,-.08])[0],[2.,2.],atol=1e-14)

    def test_odom_global_frame_choice_does_not_change_propagation(self):
        local = np.asarray([[0.,0.,0.],[.5,0.,0.],[1.,0.,-math.pi/2],[1.,-.5,-math.pi/2]])
        changed = local.copy()
        changed[:,:2] = local[:,:2]@legacy.rotation(.7).T+np.asarray([20.,-7.])
        changed[:,2] += .7
        a,_ = r.initial_base(local,[2.,2.,.2],math.pi/2,[.12,-.08])
        b,_ = r.initial_base(changed,[2.,2.,.2],math.pi/2,[.12,-.08])
        np.testing.assert_allclose(a,b,atol=1e-12)

    def test_synthetic_turning_graph_with_height_and_lever(self):
        anchors = {'a':[0.,0.,2.2],'b':[5.,0.,2.7],'c':[5.,5.,2.4],'d':[0.,5.,2.1]}
        local = np.asarray([[0.,0.,0.],[.5,0.,0.],[1.,0.,-math.pi/2],[1.,-.5,-math.pi/2]])
        expected,start = r.initial_base(local,[2.,2.,.2],math.pi/2,[.12,-.08])
        ant = r.antenna(expected,[.12,-.08])
        obs = [{k:float(np.linalg.norm(np.r_[p,.2]-np.asarray(xyz))) for k,xyz in anchors.items()} for p in ant]
        params = {'odom_translation_sigma_m':.03,'odom_yaw_sigma_deg':2.,
                  'prior_position_sigma_m':.2,'prior_heading_sigma_deg':5.,'range_sigma_m':.2}
        got,info = legacy.optimize_graph(local,obs,anchors,{k:0. for k in anchors},.2,start,
            math.pi/2,np.arange(4.),params,tag_to_base_lever_xy_m=[.12,-.08])
        self.assertTrue(info['optimizer_success'])
        self.assertLess(info['cost'],1e-15)
        np.testing.assert_allclose(r.antenna(got,[.12,-.08]),ant,atol=1e-9)

    def test_failed_optimizer_is_preserved_and_never_marked_success(self):
        local = np.asarray([[0.,0.,0.],[.1,0.,0.],[.2,0.,0.]])
        fake = SimpleNamespace(success=False,message='evaluation limit',nfev=300,njev=250,
            cost=12.,status=0,optimality=2.,x=np.zeros(9))
        args = (local,[{'a':3.}]*3,{'a':[0.,0.,2.]},{'a':0.},.2,[2.,2.],0.,np.arange(3.),
            {'odom_translation_sigma_m':.03,'odom_yaw_sigma_deg':2.,'prior_position_sigma_m':.2,
             'prior_heading_sigma_deg':5.,'range_sigma_m':.2})
        with patch.object(legacy,'least_squares',return_value=fake):
            with self.assertRaises(ValueError):
                legacy.optimize_graph(*args)
            states,info = legacy.optimize_graph(*args,raise_on_failure=False)
        self.assertFalse(info['optimizer_success'])
        self.assertEqual(info['optimizer_status'],0)
        self.assertEqual(states.shape,(3,3))

    def test_endpoint_statistic_uses_fixed_half_open_window_and_antenna(self):
        t = np.arange(5.)
        states = np.column_stack((t,np.zeros(5),np.zeros(5)))
        before = states.copy()
        e = r.endpoint_result(t,states,[1.,4.],[2.12,-.08,.2],[.12,-.08])
        self.assertEqual(e['state_samples'],3)
        self.assertAlmostEqual(e['planar_difference_m'],0.)
        np.testing.assert_array_equal(states,before)
        args = inspect.signature(legacy.optimize_graph).parameters
        self.assertNotIn('endpoint',args)
        self.assertNotIn('end_reference',args)


class RebuildFilterTests(unittest.TestCase):
    def test_baseline_validity_retains_raw_definition(self):
        for raw,reason in [([], 'missing'),([3.,3.], 'duplicate'),([float('nan')], 'nonfinite'),
                           ([float('inf')], 'nonfinite'),([0.], 'nonpositive'),([-1.], 'nonpositive')]:
            self.assertEqual(r.valid_value(raw),(None,reason))
        self.assertEqual(r.valid_value([3.]),(3.,'valid'))

    def test_isolated_jump_is_removed_uniformly_without_mutating_raw(self):
        vals = [3.]*31
        vals[15] = 5.
        data = fixture_data(vals)
        original = copy.deepcopy(data)
        rows = r.filter_rows(data,fixture_config())
        bad = [x for x in rows if x['B_keep'] and not x['C_keep']]
        self.assertEqual({(x['frame'],x['node']) for x in bad},{(15,'a'),(15,'b')})
        self.assertTrue(all(x['C_reason']=='centered_hampel' for x in bad))
        self.assertEqual(data,original)

    def test_motion_sized_ramp_and_stable_bias_are_not_spikes(self):
        vals = 3.+.1*np.arange(100)*.02+.6
        rows = r.filter_rows(fixture_data(vals),fixture_config())
        self.assertTrue(all(x['C_keep'] for x in rows))

    def test_physical_impossibility_is_separate_from_mad(self):
        cfg = fixture_config()
        rows = r.filter_rows(fixture_data([1.]),cfg)
        self.assertTrue(all(x['B_keep'] and not x['C_keep'] for x in rows))
        self.assertTrue(all(x['C_reason']=='below_vertical_geometry_bound' for x in rows))
        self.assertTrue(all(not x['support_sufficient'] for x in rows))

    def test_self_is_excluded_and_insufficient_support_keeps_feasible_value(self):
        cfg = fixture_config()
        data = fixture_data([3.]*9+[5.])
        rows = r.filter_rows(data,cfg)
        last = [x for x in rows if x['frame']==9]
        self.assertTrue(all(x['neighbors']==9 and not x['support_sufficient'] and x['C_keep'] for x in last))

    def test_exact_threshold_boundary_is_kept(self):
        cfg = fixture_config()
        cfg['filter']['absolute_floor_m'] = .5
        vals = [3.]*31
        vals[15] = 3.5
        rows = r.filter_rows(fixture_data(vals),cfg)
        self.assertTrue(all(x['C_keep'] for x in rows))

    def test_receipt_gap_does_not_become_range_rejection(self):
        cfg = fixture_config()
        a = fixture_data([3.]*31)
        b = copy.deepcopy(a)
        for row in b['uwb'][15:]:
            row['receive_s'] += .43
        first = r.filter_rows(a,cfg)
        second = r.filter_rows(b,cfg)
        self.assertEqual([(x['C_keep'],x['C_reason']) for x in first],
                         [(x['C_keep'],x['C_reason']) for x in second])

    def test_filter_is_independent_of_evaluation_endpoint(self):
        a = fixture_config()
        b = copy.deepcopy(a)
        b['evaluation']['endpoints_xyz_m'] = {'x':[1000.,-999.,.2]}
        data = fixture_data([3.]*15+[5.]+[3.]*15)
        self.assertEqual(r.filter_rows(data,a),r.filter_rows(data,b))

    def test_filtering_changes_observations_but_keeps_keyframes_and_initial_state(self):
        cfg = fixture_config()
        data = fixture_data([3.]*51,np.arange(51)*.1)
        data['odom'] = [[i*.1,i*.001,0.,0.,i*.1+.04] for i in range(51)]
        ledger = r.filter_rows(data,cfg)
        for row in ledger:
            if row['node']=='a' and 1.5 <= row['header_s'] <= 2.5:
                row['C_keep'] = False
        t,local,initial,start,obs,bins = r.build_inputs(data,cfg,ledger)
        self.assertEqual(t.tolist(),[1.,2.,3.,4.])
        self.assertIn('a',obs['B'][1])
        self.assertNotIn('a',obs['C'][1])
        self.assertEqual({x['time_s'] for x in bins if x['method']=='B'},
                         {x['time_s'] for x in bins if x['method']=='C'})
        np.testing.assert_allclose(r.antenna(initial,cfg['base_to_antenna_body_xy_m'])[0],[2.,2.])


class CommandBoundaryTests(unittest.TestCase):
    def test_window_uses_first_stop_after_last_forward(self):
        cmd = [[0.,0.,0.,0.],[.1,.045,0.,0.],[.2,.045,0.,0.],[.3,0.,0.,0.],
               [.4,0.,0.,-.2],[.5,0.,0.,-.2],[.6,0.,0.,0.],[.8,.045,0.,.02],
               [.9,.045,0.,0.],[1.,0.,0.,0.],[1.1,0.,0.,0.]]
        b = r.command_bounds(cmd)
        self.assertEqual(b['forward'][-1]['last_forward_s'],.9)
        self.assertEqual(b['forward'][-1]['end_s'],1.)
        self.assertEqual(b['evaluation_window_s'],[3.,8.])

    def test_unterminated_or_discontinuous_forward_fails(self):
        with self.assertRaises(ValueError):
            r.command_bounds([[0.,.045,0.,0.]])
        with self.assertRaises(ValueError):
            r.command_bounds([[0.,.045,0.,0.],[1.,0.,0.,0.],[2.,.045,0.,0.],[3.,0.,0.,0.]])


ARTIFACT = os.environ.get('UWB_REBUILD_RUN')


@unittest.skipUnless(ARTIFACT,'Set UWB_REBUILD_RUN for actual-artifact checks')
class ActualArtifactTests(unittest.TestCase):
    def setUp(self):
        self.out = Path(ARTIFACT)
        self.cfg = r.read_json(self.out/'frozen_config.json')
        self.manifest = r.read_json(self.out/'input_manifest.json')

    def test_input_identity_topic_counts_and_source_freeze(self):
        index = r.read_json(self.out/'evidence/index/dataset_index.json')
        for selected in self.manifest['selected_inputs']:
            record = next(x for x in index['bags'] if x['filename']==selected['bag'])
            self.assertEqual(record['sha256'],selected['sha256'])
            self.assertEqual(record['size_bytes'],selected['size_bytes'])
            self.assertEqual(record['topics'],selected['topic_counts'])
        for rel,h in r.read_json(self.out/'baseline/source_hashes_at_run.json').items():
            self.assertEqual(r.checksum(r.REPO/rel),h)

    def test_complete_ledger_conserves_each_frame_and_node(self):
        for run in r.BAGS:
            data = r.load_data(self.out,run)
            ledger = d.load_ledger(self.out/'baseline'/f'{run}_filter_ledger.csv')
            self.assertEqual(len(ledger),len(data['uwb'])*len(self.cfg['anchors_xyz_m']))
            self.assertEqual(len({(x['frame'],x['node']) for x in ledger}),len(ledger))
            self.assertTrue(all(not x['C_keep'] or x['B_keep'] for x in ledger))
            summary = r.read_json(self.out/'baseline/summary.json')
            c = next(s for s in summary if s['run']==run and s['method']=='C')
            self.assertEqual(sum(x['B_keep'] and not x['C_keep'] for x in ledger),c['additional_rejected_observations'])

    def test_six_results_share_times_and_recompute_endpoint_without_refit(self):
        rows = d.read_csv(self.out/'baseline/trajectories.csv')
        summary = r.read_json(self.out/'baseline/summary.json')
        self.assertEqual(len(summary),6)
        for run in r.BAGS:
            data = r.load_data(self.out,run)
            reference_times = None
            for method in ['A','B','C']:
                t,poses = d.pose_rows(rows,run,method)
                if reference_times is None:
                    reference_times = t
                np.testing.assert_array_equal(t,reference_times)
                s = next(s for s in summary if s['run']==run and s['method']==method)
                self.assertTrue(s['accepted_solve'])
                e = r.endpoint_result(t,poses,data['bounds']['evaluation_window_s'],
                    self.cfg['evaluation']['endpoints_xyz_m'][run],self.cfg['base_to_antenna_body_xy_m'])
                self.assertEqual(e,s['endpoint'])
                self.assertEqual(e['state_samples'],5)

    def test_b_c_factor_differences_only_follow_ledger_filter(self):
        for run in r.BAGS:
            data = r.load_data(self.out,run)
            ledger = d.load_ledger(self.out/'baseline'/f'{run}_filter_ledger.csv')
            t,local,initial,start,obs,bins = r.build_inputs(data,self.cfg,ledger)
            saved = d.read_csv(self.out/'baseline'/f'{run}_range_bins.csv')
            self.assertEqual(len(bins),len(saved))
            for computed,stored in zip(bins,saved):
                self.assertEqual(computed['method'],stored['method'])
                self.assertEqual(computed['raw_support'],int(stored['raw_support']))
                self.assertEqual(computed['factor_present'],stored['factor_present']=='True')
                if computed['range_m'] is not None:
                    self.assertEqual(computed['range_m'],float(stored['range_m']))


if __name__ == '__main__':
    unittest.main()
