#!/usr/bin/env python3
"""Create verified, bag-free checkpoint/review ZIPs without touching Git state."""
import argparse
import hashlib
import json
import os
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

REPO = Path(__file__).resolve().parents[1]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--stage', required=True)
    p.add_argument('--deliverables', type=Path, default=Path('/workspace/output/uwb_rebuilt_20261020'))
    args = p.parse_args()
    run = args.run.resolve()
    assert run.is_relative_to(REPO)
    args.deliverables.mkdir(parents=True, exist_ok=True)
    dest = args.deliverables/f'uwb_single_car_rebuilt_20261020_{args.stage}.zip'
    if dest.exists():
        raise FileExistsError('Refusing to overwrite checkpoint '+str(dest))
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    def git(*a):
        return subprocess.check_output(['git','-C',str(REPO),*a],env=env)
    source_paths = [REPO/'HANDOFF.md', Path(__file__).resolve(),
        REPO/'tools/rebuild_oct18_single_car.py', REPO/'tools/diagnose_oct18_rebuild.py',
        REPO/'tools/test_oct18_rebuild.py', REPO/'tools/analyze_october_field_session.py',
        REPO/'tools/test_october_field_session.py', REPO/'tools/diagnose_october_L_segments.py',
        REPO/'tools/requirements-october-modern.txt', REPO/'docs/field_tests/20261017/session_config.json']
    # Include every changed/untracked file body, even when absent from Git diff.
    changed = git('diff','--name-only','-z','HEAD').decode().split('\0')
    untracked = git('ls-files','--others','--exclude-standard','-z').decode().split('\0')
    for rel in changed+untracked:
        if rel:
            source_paths.append(REPO/rel)
    source_paths += [f for f in run.rglob('*') if f.is_file()]
    payload = {}
    excluded = []
    for f in sorted(set(source_paths)):
        if not f.is_file():
            continue
        assert f.resolve().is_relative_to(REPO)
        if f.suffix.lower() in {'.bag','.pyc','.zip','.tar','.tgz'} or '__pycache__' in f.parts:
            excluded.append(str(f.relative_to(REPO)))
            continue
        raw = f.read_bytes()
        assert not raw.startswith(b'#ROSBAG V2.0'), str(f)
        payload['repo/'+str(f.relative_to(REPO))] = raw
    payload['git/status_porcelain.txt'] = git('status','--porcelain=v1','--untracked-files=all')
    payload['git/status_branch.txt'] = git('status','--short','--branch','--untracked-files=all')
    payload['git/diff_HEAD.patch'] = git('diff','--binary','HEAD')
    payload['git/diff_staged.patch'] = git('diff','--binary','--cached')
    payload['git/worktrees.txt'] = git('worktree','list','--porcelain')
    payload['git/HEAD.txt'] = git('rev-parse','HEAD')
    payload['git/branch.txt'] = git('branch','--show-current')
    bodies = [{'path': n, 'sha256': sha(b), 'size_bytes':len(b)} for n,b in sorted(payload.items())]
    metadata = {'analysis_label':'重建分析', 'stage':args.stage,
        'created_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
        'repo_path':str(REPO),'run_path':str(run),
        'head':git('rev-parse','HEAD').decode().strip(),
        'branch':git('branch','--show-current').decode().strip(),
        'raw_bags_included':False,'excluded_files':excluded,
        'file_bodies':bodies,'changed_paths':[x for x in changed if x],
        'untracked_paths':[x for x in untracked if x],
        'note':'All changed/untracked regular non-bag files are included as bodies; patches supplement bodies.'}
    payload['PACKAGE_MANIFEST.json'] = (json.dumps(metadata,ensure_ascii=False,indent=2)+'\n').encode()
    payload['SHA256SUMS.txt'] = ''.join(f'{sha(b)}  {n}\n' for n,b in sorted(payload.items())).encode()
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,b in sorted(payload.items()):
            z.writestr(n,b)
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist()))
        assert not any(n.lower().endswith('.bag') for n in z.namelist())
        for n,b in payload.items():
            assert z.read(n) == b
        for line in z.read('SHA256SUMS.txt').decode().splitlines():
            h,n = line.split('  ',1)
            assert sha(z.read(n)) == h
    digest = sha(dest.read_bytes())
    dest.with_suffix('.zip.sha256').write_text(digest+'  '+dest.name+'\n')
    result = {'path':str(dest),'sha256':digest,'size_bytes':dest.stat().st_size,
              'members':len(payload),'crc_test':'passed','all_member_hashes':'passed','raw_bags':0}
    dest.with_suffix('.verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
