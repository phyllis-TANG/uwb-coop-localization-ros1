#!/usr/bin/env python3
"""Post-fit diagnostics for frozen Oct18 重建分析; never refit or calibrate."""
import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np

import rebuild_oct18_single_car as r


def read_csv(path):
    with Path(path).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def load_ledger(path):
    rows = read_csv(path)
    for row in rows:
        for k in ['B_keep','C_keep','support_sufficient']:
            row[k] = row[k] == 'True'
        for k in ['header_s','receive_s','raw_m','local_median_m','local_mad_m','threshold_m']:
            row[k] = float(row[k]) if row[k] else None
        for k in ['frame','neighbors']:
            row[k] = int(row[k])
    return rows


def pose_rows(rows, run, method):
    selected = [x for x in rows if x['run'] == run and x['method'] == method]
    t = np.asarray([float(x['time_s']) for x in selected])
    poses = np.asarray([[float(x[k]) for k in ['base_x_m','base_y_m','yaw_rad']] for x in selected])
    return t, poses


def summarize(prefix, values):
    return {prefix+'_'+k: v for k,v in r.distribution(values).items()}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()
    out = args.output
    dest = out/'diagnostics'
    if dest.exists():
        raise FileExistsError('Refusing to overwrite diagnostics')
    config = r.read_json(out/'frozen_config.json')
    source = r.read_json(out/'baseline/source_hashes_at_run.json')
    for rel,h in source.items():
        assert r.checksum(r.REPO/rel) == h, 'baseline source changed since fitting'
    summary = r.read_json(out/'baseline/summary.json')
    trajectories = read_csv(out/'baseline/trajectories.csv')
    dest.mkdir()
    counts, geometry, timing, receive_gaps, header_gaps = [], [], [], [], []
    drift, factor_residuals, factor_summary, coverage, coverage_summary = [], [], [], [], []
    between, priors, historical, rejected = [], [], [], []
    diagnostic_info = {'analysis_label':'重建分析', 'endpoint_used_only_for_evaluation':True,
        'calibration_applied_from_geometry_diagnostics':False, 'runs':{},
        'interpretation_limits':['candidate start unverified','base_footprint equals geometric center assumed',
            'manual endpoint/anchor uncertainty not fully quantified','batch graph is not an online system',
            'optimizer success is termination, not a certificate of global optimum']}
    for run in r.BAGS:
        data = r.load_data(out,run)
        ledger = load_ledger(out/'baseline'/f'{run}_filter_ledger.csv')
        bins = read_csv(out/'baseline'/f'{run}_range_bins.csv')
        window = data['bounds']['evaluation_window_s']
        windows = [{'phase':'ALL','start_s':-math.inf,'end_s':math.inf}]+data['phases']+[
            {'phase':'evaluation','start_s':window[0],'end_s':window[1]}]
        rejected.extend(dict(run=run,**x) for x in ledger if x['B_keep'] and not x['C_keep'])
        for phase in windows:
            for node in config['anchors_xyz_m']:
                selected = [x for x in ledger if x['node']==node and phase['start_s'] <= x['header_s'] < phase['end_s']]
                valid = [x for x in selected if x['B_keep']]
                counts.append({'run':run,'phase':phase['phase'],'node':node,
                    'header_window_start_s':phase['start_s'] if math.isfinite(phase['start_s']) else '',
                    'header_window_end_s':phase['end_s'] if math.isfinite(phase['end_s']) else '',
                    'frames':len(selected),'baseline_valid':len(valid),
                    'missing':sum(x['baseline_status']=='missing' for x in selected),
                    'duplicate':sum(x['baseline_status']=='duplicate' for x in selected),
                    'nonfinite':sum(x['baseline_status']=='nonfinite' for x in selected),
                    'nonpositive':sum(x['baseline_status']=='nonpositive' for x in selected),
                    'B_kept':len(valid),'C_kept':sum(x['C_keep'] for x in selected),
                    'extra_rejected':sum(not x['C_keep'] for x in valid),
                    'hampel_rejected':sum('centered_hampel' in x['C_reason'] for x in valid),
                    'geometry_rejected':sum('below_vertical_geometry_bound' in x['C_reason'] for x in valid),
                    'insufficient_support':sum(not x['support_sufficient'] for x in valid)})
        for node,xyz in config['anchors_xyz_m'].items():
            selected = [x for x in ledger if x['node']==node and x['B_keep'] and window[0] <= x['header_s'] < window[1]]
            raw = [x['raw_m'] for x in selected]
            kept = [x['raw_m'] for x in selected if x['C_keep']]
            distance = float(np.linalg.norm(np.asarray(config['evaluation']['endpoints_xyz_m'][run])-xyz))
            geometry.append({'run':run,'node':node,'window_start_s':window[0],'window_end_s':window[1],
                'geometric_range_m':distance,'raw_valid_header_clock':len(raw),
                'raw_valid_receipt_clock':sum(x['node']==node and x['B_keep'] and window[0] <= x['receive_s'] < window[1] for x in ledger),
                'C_kept_count':len(kept),'C_removed_count':len(raw)-len(kept),
                'raw_median_m':float(np.median(raw)) if raw else None,
                'raw_median_minus_geometry_m':float(np.median(raw)-distance) if raw else None,
                'C_median_m':float(np.median(kept)) if kept else None,
                'C_median_minus_geometry_m':float(np.median(kept)-distance) if kept else None,
                **summarize('raw',raw)})
        for topic,rows in data['timing'].items():
            receive = np.asarray([x[0] for x in rows])
            header = np.asarray([x[1] for x in rows]) if rows[0][1] is not None else None
            rd = np.diff(receive)
            hd = np.diff(header) if header is not None else None
            common = {'run':run,'topic':topic,'messages':len(rows),
                'first_receive_s':float(receive[0]),'last_receive_s':float(receive[-1]),
                'first_header_s':float(header[0]) if header is not None else None,
                'last_header_s':float(header[-1]) if header is not None else None,
                'receive_nonincreasing_steps':int(np.sum(rd <= 0)),
                'header_nonincreasing_steps':int(np.sum(hd <= 0)) if hd is not None else None,
                'max_receive_gap_s':float(rd.max()),
                'max_header_gap_s':float(hd.max()) if hd is not None else None,
                'receive_gaps_gt_100ms':int(np.sum(rd>.1)),
                'header_gaps_gt_100ms':int(np.sum(hd>.1)) if hd is not None else None,
                'gap_interpretation':'diagnostic threshold only; low-rate voltage excluded from high-frequency gap listing',
                **summarize('receive_minus_header_s',receive-header if header is not None else [])}
            timing.append(common)
            if topic not in ['/car2/uwb/ranges','/car2/odom','/car2/imu']:
                continue
            for i in np.where(rd>.1)[0]:
                receive_gaps.append({'run':run,'topic':topic,'start_receive_s':float(receive[i]),
                    'end_receive_s':float(receive[i+1]),'receive_gap_s':float(rd[i]),
                    'start_header_s':float(header[i]),'end_header_s':float(header[i+1]),
                    'header_gap_s':float(hd[i])})
            for i in np.where(hd>.1)[0]:
                header_gaps.append({'run':run,'topic':topic,'start_header_s':float(header[i]),
                    'end_header_s':float(header[i+1]),'header_gap_s':float(hd[i]),'receive_gap_s':float(rd[i])})
        fwd1,fwd2 = data['bounds']['forward']
        drift_windows = [dict(phase='initial_stationary',start_s=0.,end_s=fwd1['start_s']-.5),
            dict(phase='after_forward1_settled',start_s=fwd1['end_s']+2.,end_s=data['bounds']['turn_start_s']),
            dict(phase='after_turn_settled',start_s=data['bounds']['turn_end_s']+2.,end_s=fwd2['start_s']),
            dict(phase='post_motion_settled',start_s=fwd2['end_s']+2.,end_s=data['duration_s']),
            dict(phase='evaluation',start_s=window[0],end_s=window[1])]
        run_info = {'evaluation_window_s':window,'method_coverage':{},'timing_cause':'unknown',
                    'filter_extra_rejected':sum(x['B_keep'] and not x['C_keep'] for x in ledger)}
        odom = np.asarray(data['odom'])
        odom[:,3] = np.unwrap(odom[:,3])
        for method in ['A','B','C']:
            t,poses = pose_rows(trajectories,run,method)
            if not len(t):
                run_info['method_coverage'][method] = {'states':0,'unavailable':'entire run; optimizer failure'}
                continue
            ant = r.antenna(poses,config['base_to_antenna_body_xy_m'])
            accepted = next(s['accepted_solve'] for s in summary if s['run']==run and s['method']==method)
            for win in drift_windows:
                mask = (t>=win['start_s']) & (t<win['end_s'])
                xy = ant[mask]
                if not len(xy):
                    drift.append({'run':run,'method':method,'phase':win['phase'], 'start_s':win['start_s'],
                        'end_s':win['end_s'],'samples':0,'accepted_solve':accepted})
                    continue
                med = np.median(xy,axis=0)
                m = max(1,len(xy)//2)
                drift.append({'run':run,'method':method,'phase':win['phase'], 'start_s':win['start_s'],
                    'end_s':win['end_s'],'samples':len(xy),'accepted_solve':accepted,
                    'median_x_m':float(med[0]),'median_y_m':float(med[1]),
                    'first_to_last_m':float(np.linalg.norm(xy[-1]-xy[0])),
                    'early_late_half_median_difference_m':float(np.linalg.norm(np.median(xy[-m:],axis=0)-np.median(xy[:m],axis=0))),
                    'max_displacement_from_first_m':float(np.linalg.norm(xy-xy[0],axis=1).max()),
                    'span_x_m':float(np.ptp(xy[:,0])),'span_y_m':float(np.ptp(xy[:,1])),
                    'std_x_m':float(xy[:,0].std()),'std_y_m':float(xy[:,1].std()),
                    'difference_to_candidate_start_m':float(np.linalg.norm(med-np.asarray(config['candidate_start_antenna_xyz_m'][:2]))) if win['phase']=='initial_stationary' else None})
            selected_bins = [b for b in bins if b['method']==method]
            for i,time in enumerate(t):
                factors = [b for b in selected_bins if int(b['keyframe'])==i and b['factor_present']=='True']
                low, high = time-config['graph_parameters']['range_bin_half_width_s'], time+config['graph_parameters']['range_bin_half_width_s']
                nearest = float(np.min(np.abs(odom[:,0]-time)))
                pos = int(np.searchsorted(odom[:,0],time))
                bracket = float(odom[pos,0]-odom[pos-1,0]) if 0 < pos < len(odom) else None
                coverage.append({'run':run,'method':method,'keyframe':i,'time_s':float(time),
                    'phase':r.phase_at(time,data['phases']),'accepted_solve':accepted,
                    'odom_interpolation_within_coverage':bool(odom[0,0]<=time<=odom[-1,0]),
                    'nearest_odom_header_s':nearest,'odom_bracket_gap_s':bracket,
                    'bin_start_s':float(low),'bin_end_s':float(high),'range_factors':len(factors),
                    'raw_range_support':sum(int(b['raw_support']) for b in factors),
                    'nodes':'|'.join(b['node'] for b in factors),
                    'standalone_xy_support_ge3':len(factors)>=3 if method!='A' else None,
                    'no_direct_range_factor':not factors,
                    'note':'A deliberately has no range factors' if method=='A' else 'no continuous truth; graph also uses odom/prior'})
            run_info['method_coverage'][method] = {'states':len(t),'accepted_solve':accepted,
                'first_header_state_s':float(t[0]),'last_header_state_s':float(t[-1]),
                'outside_keyframe_domain_s':[[0.,float(t[0])],[float(t[-1]),data['duration_s']]],
                'interior_state_gaps_gt_step':int(np.sum(np.diff(t)>config['graph_parameters']['keyframe_step_s']+1e-9)),
                'range_factor_free_keyframes':sum(x['run']==run and x['method']==method and x['no_direct_range_factor'] for x in coverage),
                'unavailable_accepted_solution_intervals':[] if accepted else [[float(t[0]),float(t[-1])]]}
            for ph in data['phases']:
                cr = [x for x in coverage if x['run']==run and x['method']==method and x['phase']==ph['phase']]
                coverage_summary.append({'run':run,'method':method,'phase':ph['phase'],'states':len(cr),
                    'accepted_states':sum(x['accepted_solve'] for x in cr),
                    'range_factors':sum(x['range_factors'] for x in cr),
                    'range_factor_free_keyframes':sum(x['no_direct_range_factor'] for x in cr),
                    'standalone_xy_unavailable_keyframes':sum(not x['standalone_xy_support_ge3'] for x in cr) if method!='A' else None,
                    'max_odom_bracket_gap_s':max((x['odom_bracket_gap_s'] for x in cr),default=None)})
            if method in ['B','C']:
                for b in selected_bins:
                    if b['factor_present']!='True':
                        continue
                    i = int(b['keyframe'])
                    node = b['node']
                    distance = float(np.linalg.norm(np.r_[ant[i],config['antenna_height_m']]-np.asarray(config['anchors_xyz_m'][node])))
                    error = distance-float(b['range_m'])
                    scaled = error/config['graph_parameters']['range_sigma_m']
                    factor_residuals.append({'run':run,'method':method,'keyframe':i,'time_s':float(t[i]),
                        'phase':b['phase'],'node':node,'bin_range_m':float(b['range_m']),
                        'model_range_m':distance,'model_minus_measured_m':error,
                        'normalized_error':scaled,'pseudo_huber_relative_influence':1/math.sqrt(1+scaled*scaled),
                        'pseudo_huber_cost':math.sqrt(1+scaled*scaled)-1})
                local = np.column_stack([np.interp(t,odom[:,0],odom[:,j]) for j in [1,2,3]])
                def increments(a):
                    delta = np.diff(a[:,:2],axis=0)
                    th = a[:-1,2]
                    body = np.column_stack((np.cos(th)*delta[:,0]+np.sin(th)*delta[:,1],
                                            -np.sin(th)*delta[:,0]+np.cos(th)*delta[:,1]))
                    return body,r.legacy.wrap(np.diff(a[:,2]))
                actual,actual_yaw = increments(poses)
                expected,expected_yaw = increments(local)
                for i in range(len(t)-1):
                    sigma_xy = config['graph_parameters']['odom_translation_sigma_m']*math.sqrt(t[i+1]-t[i])
                    sigma_yaw = math.radians(config['graph_parameters']['odom_yaw_sigma_deg'])*math.sqrt(t[i+1]-t[i])
                    delta = actual[i]-expected[i]
                    dyaw = float(r.legacy.wrap(actual_yaw[i]-expected_yaw[i]))
                    between.append({'run':run,'method':method,'from_s':float(t[i]),'to_s':float(t[i+1]),
                        'body_dx_error_m':float(delta[0]),'body_dy_error_m':float(delta[1]),
                        'yaw_error_deg':math.degrees(dyaw),'normalized_dx':float(delta[0]/sigma_xy),
                        'normalized_dy':float(delta[1]/sigma_xy),'normalized_yaw':dyaw/sigma_yaw})
                _,start_base = r.initial_base(local,config['candidate_start_antenna_xyz_m'],math.radians(config['initial_heading_deg']),config['base_to_antenna_body_xy_m'])
                priors.append({'run':run,'method':method,'base_dx_m':float(poses[0,0]-start_base[0]),
                    'base_dy_m':float(poses[0,1]-start_base[1]),
                    'heading_error_deg':math.degrees(float(r.legacy.wrap(poses[0,2]-math.radians(config['initial_heading_deg']))))})
            s = next(s for s in summary if s['run']==run and s['method']==method)
            old = r.HISTORICAL[run][['A','B','C'].index(method)]
            historical.append({'run':run,'method':method,'rebuilt_planar_difference_m':s['endpoint']['planar_difference_m'],
                'historical_report_only_m':old,'rebuilt_minus_historical_m':s['endpoint']['planar_difference_m']-old,
                'historical_artifact_verified':False,
                'rebuilt_extra_rejected':s['additional_rejected_observations'] if method=='C' else None,
                'historical_reported_extra_rejected':{'004023':318,'005135':46}[run] if method=='C' else None})
        imu = np.asarray(data['imu'])
        bias = float(np.median(imu[(imu[:,0]>=0)&(imu[:,0]<5),1]))
        integrand = .5*(imu[1:,1]+imu[:-1,1]-2*bias)*np.diff(imu[:,0])
        run_info['imu_diagnostic'] = {'initial_5s_median_wz_rad_s':bias,
            'integrated_yaw_deg':math.degrees(float(np.sum(integrand))),
            'odom_yaw_change_deg':math.degrees(float(odom[-1,3]-odom[0,3])),
            'independence':'gyro and odom yaw may share source; no independent heading truth'}
        diagnostic_info['runs'][run] = run_info
    for run in r.BAGS:
        for method in ['B','C']:
            for phase in ['ALL']+[p['phase'] for p in r.load_data(out,run)['phases']]:
                for node in config['anchors_xyz_m']:
                    rows = [x for x in factor_residuals if x['run']==run and x['method']==method and x['node']==node and (phase=='ALL' or x['phase']==phase)]
                    factor_summary.append({'run':run,'method':method,'phase':phase,'node':node,
                        **summarize('model_minus_measured_m',[x['model_minus_measured_m'] for x in rows]),
                        **summarize('absolute_residual_m',[abs(x['model_minus_measured_m']) for x in rows])})
    for name,rows in [('filter_counts_by_phase_node',counts),('endpoint_geometry_residuals',geometry),
        ('time_topic_summary',timing),('receive_gaps_over_100ms',receive_gaps),
        ('initial_and_static_drift',drift),('range_factor_residuals',factor_residuals),
        ('residual_summary_by_phase_node',factor_summary),('keyframe_coverage',coverage),
        ('coverage_by_phase',coverage_summary),('odom_between_residuals',between),
        ('prior_residuals',priors),('historical_comparison',historical),('rejected_observations',rejected)]:
        fields = list(dict.fromkeys(k for row in rows for k in row))
        r.write_csv(dest/(name+'.csv'),rows,fields)
    r.write_csv(dest/'header_gaps_over_100ms.csv',header_gaps,
                ['run','topic','start_header_s','end_header_s','header_gap_s','receive_gap_s'])
    r.write_json(dest/'diagnostic_summary.json',diagnostic_info)
    plot(out,dest,config,trajectories,geometry)
    print(json.dumps(diagnostic_info,ensure_ascii=False,indent=2))


def plot(out,dest,config,trajectories,geometry):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    colors = {'A':'#3069a4','B':'#c56632','C':'#329568'}
    fig,axs = plt.subplots(1,2,figsize=(12,5),layout='constrained')
    for ax,run in zip(axs,r.BAGS):
        for method in ['A','B','C']:
            t,poses = pose_rows(trajectories,run,method)
            if not len(t):
                continue
            xy = r.antenna(poses,config['base_to_antenna_body_xy_m'])
            ax.plot(xy[:,0],xy[:,1],label=method,color=colors[method],lw=1.5,ls='--' if method=='C' else '-')
            summary = r.read_json(out/'baseline/summary.json')
            s = next(x for x in summary if x['run']==run and x['method']==method)
            ax.scatter(*s['endpoint']['median_antenna_xy_m'],color=colors[method],s=40)
        ax.scatter(*config['evaluation']['endpoints_xyz_m'][run][:2],marker='x',s=100,c='black',label='Manual endpoint')
        ax.scatter(*config['candidate_start_antenna_xyz_m'][:2],marker='s',s=60,facecolors='none',edgecolors='black',label='Candidate start')
        ax.set(title=run+' | rebuilt, conditional',xlabel='Antenna X (m)',ylabel='Antenna Y (m)')
        ax.axis('equal'); ax.grid(alpha=.2); ax.legend(fontsize=8)
    fig.savefig(dest/'antenna_trajectories.png',dpi=180)
    plt.close(fig)
    fig,axs = plt.subplots(1,2,figsize=(11,4),layout='constrained')
    for ax,run in zip(axs,r.BAGS):
        rows = [x for x in geometry if x['run']==run]
        ax.bar([x['node'] for x in rows],[x['raw_median_minus_geometry_m'] for x in rows],color='#637dac')
        ax.axhline(0,color='black',lw=.6)
        ax.set(title=run+' | same fixed endpoint window',ylabel='Raw median - manual geometry (m)')
        ax.grid(axis='y',alpha=.2)
    fig.savefig(dest/'endpoint_geometry_bias.png',dpi=180)
    plt.close(fig)


if __name__ == '__main__':
    main()
