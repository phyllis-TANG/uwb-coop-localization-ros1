#!/usr/bin/env python3
"""Render the saved reconstruction evidence; no optimization or tuning."""
import argparse
import csv
import json
from pathlib import Path

import rebuild_oct18_single_car as r
import diagnose_oct18_rebuild as d


def table(headers, rows):
    return '\n'.join(['| '+' | '.join(headers)+' |',
        '| '+' | '.join(['---']*len(headers))+' |']+
        ['| '+' | '.join(str(v) for v in row)+' |' for row in rows])+'\n'


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    out = args.output
    if (out/'REPORT.md').exists():
        raise FileExistsError('Report already exists')
    manifest = r.read_json(out/'input_manifest.json')
    config = r.read_json(out/'frozen_config.json')
    summary = r.read_json(out/'baseline/summary.json')
    diag = r.read_json(out/'diagnostics/diagnostic_summary.json')
    tests = r.read_json(out/'tests/test_report.json')
    counts = d.read_csv(out/'diagnostics/filter_counts_by_phase_node.csv')
    geometry = d.read_csv(out/'diagnostics/endpoint_geometry_residuals.csv')
    drift = d.read_csv(out/'diagnostics/initial_and_static_drift.csv')
    residuals = d.read_csv(out/'diagnostics/residual_summary_by_phase_node.csv')
    times = d.read_csv(out/'diagnostics/time_topic_summary.csv')
    src = out/'evidence/committed_source'
    src.mkdir(exist_ok=True)
    (src/'analyze_october_field_session.py').write_bytes(r.git('show','HEAD:tools/analyze_october_field_session.py').encode())
    r.write_json(out/'evidence/initial_git_status.json',{
        'observation_source':'first read-only command in this reconstruction turn, before edits; recorded here retrospectively',
        'repo':'/workspace/uwb-coop-localization-ros1','branch':'work',
        'head':'9bf4f01fb778630006b52f7e6e3758f1ae68435e','status_porcelain':'',
        'note':'input_manifest.git_at_prepare is a later snapshot after reconstruction scripts had been created'})
    source_files = sorted(set([r.REPO/'tools'/n for n in [
        'analyze_october_field_session.py','rebuild_oct18_single_car.py','diagnose_oct18_rebuild.py',
        'report_oct18_rebuild.py','package_oct18_rebuild.py','test_oct18_rebuild.py',
        'test_october_field_session.py','diagnose_october_L_segments.py','requirements-october-modern.txt']]))
    r.write_json(out/'input_source_hashes.json',{
        'analysis_label':'重建分析','input_attachments':manifest['attachments'],
        'input_bags':[{'bag':x['bag'],'sha256':x['sha256'],'size_bytes':x['size_bytes']} for x in manifest['selected_inputs']],
        'frozen_config_sha256':r.checksum(out/'frozen_config.json'),
        'committed_analyzer_sha256':r.checksum(src/'analyze_october_field_session.py'),
        'source_sha256':{str(p.relative_to(r.REPO)):r.checksum(p) for p in source_files},
        'baseline_source_hash_record':'baseline/source_hashes_at_run.json',
        'test_source_hash_record':'tests/test_report.json'})
    # Preserve stage package identities without nesting archives or introducing
    # a self-referential hash for the final package.
    checkpoints = []
    root = Path('/workspace/output/uwb_rebuilt_20261020')
    for p in sorted(root.glob('*.verification.json')):
        checkpoints.append(r.read_json(p))
    r.write_json(out/'checkpoints.json',checkpoints)
    text = ['# 10月18日两包单车离线基线复核：重建分析\n',
        '日期：2026-10-20（Asia/Shanghai）。本轮从已提交代码、已核验原始数据和冻结说明重新计算。旧任务云端不可访问，其未提交源码、配置和产物未恢复。以下计算不是旧成果恢复，也不声称精确复现旧 C。\n',
        '## 结果与使用边界\n',
        '在冻结的候选起点、朝向、参考点关系和原始零偏差测距条件下，四组融合优化均成功终止，但两个包的 B/C 终点平面差都大于 A；本轮未验证融合优于 odom。短时异常筛选并未去除末窗的正向几何差异。人工终点只用于下表和几何诊断，未进入筛选、初始对齐或优化。无连续真值，不报告轨迹 RMSE/ATE 或在线性能。\n',
        table(['包','方案','天线X中位数 m','天线Y中位数 m','终点平面差 m','末窗状态数','新增剔除数'],[
            [s['run'],s['method'],f"{s['endpoint']['median_antenna_xy_m'][0]:.9f}",
             f"{s['endpoint']['median_antenna_xy_m'][1]:.9f}",f"{s['endpoint']['planar_difference_m']:.9f}",
             s['endpoint']['state_samples'],s['additional_rejected_observations']] for s in summary]),
        'A：仅 odom。B：既有单车图方法＋原始有效测距（保留原中位数聚合与伪 Huber）。C：同 B，仅在聚合前加入本轮冻结筛选。共有 564 行轨迹：004023 每方案 96 帧，005135 每方案 92 帧。\n',
        '![天线轨迹与终点](diagnostics/antenna_trajectories.png)\n',
        '## 现场与输入身份\n',
        f"实际仓库 `/workspace/uwb-coop-localization-ros1`，起始分支 `work`，完整 HEAD `{manifest['git_at_prepare']['head']}`。首次只读 status 干净。`input_manifest.json` 中 git_at_prepare 是创建本轮代码后的稍后快照；首次检查另见 `evidence/initial_git_status.json`。未切分支、提交、推送、合并、reset 或 clean。\n",
        '可访问范围：当前 `/workspace`（含隐藏及忽略文件）、可读 `/tmp`、附件及其成员列表；`/mnt`、`/media` 无数据；旧云端不可访问，Docker socket 在初始检查时无访问权限。未找到旧审核包、根 HANDOFF、single_car_baseline_20261020、旧两审核脚本或 analyzer 未提交修改。已提交 two_car_graph 结果属于其他任务，未当作单车成果复用。可见进程没有相关分析任务；本轮各阶段只启动一次，未重复计算基线。\n',
        table(['附件','SHA-256','核验'],[[x['name'],x['sha256'],'通过'] for x in manifest['attachments']]),
        '交接清单验证两份归档；索引 ZIP CRC 通过；场测归档内全部18个 bag 哈希均核验，实际消息分析只读取以下两包。新 ZIP 中不含原始 bag。\n',
        table(['包','字节数','SHA-256','UWB/odom/IMU消息数'],[
            [x['bag'],x['size_bytes'],x['sha256'],
             '/'.join(str(x['topic_counts']['/car2/'+k]) for k in ['uwb/ranges','odom','imu'])] for x in manifest['selected_inputs']]),
        '完整阅读并保存 `evidence/index/云端下一轮指令.md`、U001/U002。索引表中的文件 SHA、字节数和话题计数与本轮解码一致，由真实产物测试核验。附件内历史命令仅保存为证据，没有执行。\n',
        '## 确认、候选、假设与未知\n',
        table(['类别','本轮登记'],[
            ['用户确认 U001/U002','004023终点天线中心(2.97,3.11,0.20)m；005135为(2.93,3.04,0.20)m；两包起始朝+Y，忽略小摆放角误差；10月18日墙节点沿用10月17日重装配置'],
            ['候选设置','起点天线中心(2,2,0.20)m，仅来自用户回忆和其他L形备注R012/R033，非本包独立实测；计划终点(3,3,0.20)m不用作真值'],
            ['模型假设','近似底盘几何中心等于odom base_footprint；水平外参(+0.12,-0.08)m按车体yaw旋转；固定天线高0.20m；无额外偏差校正'],
            ['未知事项','真实起点数值、精确摆放角误差、参考点关系、墙节点及人工终点测量不确定度、异常硬件/传播原因、旧C筛选完整参数']]),
        '10月11日083053按用户确认失败排除，本轮完全不分析。005135“正常录制”仅为现场状态，不表示测距全程无异常。\n',
        '## 实现与冻结参数\n',
        '详见 `METHOD_REVIEW.md`、`frozen_config.json`。复用提交代码的单车 SE(2) 批量图；没有把 UWB-only 在线节点称作 UWB+odom 在线融合。仅做可选旋转外参和优化状态保留的兼容适配，旧调用默认仍为零水平偏移。\n',
        table(['节点','X m','Y m','Z m'],[[k]+v for k,v in config['anchors_xyz_m'].items()]),
        '距离为三维距离 sqrt((tag_x-anchor_x)^2+(tag_y-anchor_y)^2+(0.20-anchor_z)^2)。base_xy=tag_xy−R(yaw)·lever；初始90°时 base候选为(1.92,1.88)m。odom增量在前一帧车体坐标计算，yaw差做wrap，避免把水平偏移直接加到odom全局XY。\n',
        table(['参数','冻结值'],[
            ['关键帧/中位数测距聚合','1s；±0.4s窗，至少5条有效观测/节点；保持提交版起止覆盖保护'],
            ['时间关联','传感器header；无header的cmd用接收时间；共同减bag首条记录时刻；不估计时延修正'],
            ['odom平移/角度sigma','0.03m×sqrt(dt) / 2deg×sqrt(dt)'],
            ['起点位置/朝向先验sigma','0.2m / 5deg'],
            ['测距sigma/额外偏差','0.2m / 所有节点0m，不使用旧P1校正'],
            ['鲁棒损失','仅测距采用原伪Huber，标准化误差e的cost=sqrt(1+e²)−1，delta=1；其余Gaussian'],
            ['优化','SciPy least_squares，线性外层损失，稀疏有限差分；max_nfev=300，ftol/xtol/gtol=1e−7'],
            ['权重状态','沿用10月17日、来自试验版本，尚未独立验证；未根据终点调整']]),
        'B/C 共用先验、初值、odom、外参、时钟、关键帧、权重和损失，仅测距成员筛选不同。IMU只用于诊断，odom yaw可能已使用同源陀螺仪。\n',
        '## 原始指令与固定评价窗\n',
        table(['包','最后非零前进指令 s','后续首条停止指令 s','评价窗 [s,s)','状态时刻 s','状态数/各节点原始数'],[
            [x['run'],f"{x['bounds']['forward'][-1]['last_forward_s']:.9f}",
             f"{x['bounds']['forward'][-1]['end_s']:.9f}",
             ' / '.join(f'{v:.9f}' for v in x['bounds']['evaluation_window_s']),
             '82,83,84,85,86' if x['run']=='004023' else '84,85,86,87,88','5 / 250'] for x in manifest['selected_inputs']]),
        '停止边界不是最后非零样本时刻；前进按vx>0.005m/s，主转弯按无前进且|wz|>0.04rad/s；前进指令连续性检查最大间隙<0.5s。完整指令、原索引分段和本轮相位边界都保存。区间统一左闭右开，未按误差选窗。传感器header与指令接收时刻存在未量化延迟；004023同一数值窗口按接收时钟计为251条/节点、按header为250条，005135均250条。主结果统一使用header选传感器样本。\n',
        '## 本轮探索性统一筛选及账本\n',
        '版本 `rebuild_exploratory_physical_hampel_v1`，运行前冻结。原始有效要求节点条目唯一、有限且>0；缺失/重复/非法另列。C新增：r<|anchor_z−0.20|−0.05m剔除；随后以同节点header时间±0.5s原始有效邻居（不含自身、非迭代、至少10条）求中位数和MAD，|r−median|>max(0.35m,4.5×1.4826×MAD)剔除。邻居不足时保留物理可行值并标记。0.35m来自探索性0.20m/s天线速度包络×0.5s+0.25m余量，未独立验证，不来自人工终点。所有节点和两包完全相同，未用索引跳变窗口作硬掩码。\n',
        table(['包','节点','原始帧槽','有效 B','原始缺失','C保留','新增剔除'],[
            [x['run'],x['node'],x['frames'],x['B_kept'],x['missing'],x['C_kept'],x['extra_rejected']]
            for x in counts if x['phase']=='ALL']),
        '完整账本38520行，含header/接收时间、原始值、节点、原因及窗口统计；新增剔除367条全部触发Hampel，物理下界未触发，实际两包无重复/非有限/非正条目。未把缺失当作新增剔除。各阶段/节点计数在 `diagnostics/filter_counts_by_phase_node.csv`。筛选只能检测局部不一致，不能认证被剔除值一定错误，也不能消除稳定偏置或多数污染。\n',
        '## 末窗几何差异：仅诊断，不校准\n',
        table(['包','节点','几何距离 m','原始中位数 m','原始−几何 m','原始std m','C中位数−几何 m','C末窗剔除'],[
            [x['run'],x['node']]+[f"{float(x[k]):.6f}" for k in ['geometric_range_m','raw_median_m','raw_median_minus_geometry_m','raw_std','C_median_minus_geometry_m']]+[x['C_removed_count']] for x in geometry]),
        '![末窗几何差异](diagnostics/endpoint_geometry_bias.png)\n',
        '所有节点末窗中位数均高于冻结几何距离，约+0.20至+0.54m。004023的N8波动较大（std约0.254m）；筛除23条后中位数差仍+0.2665m。N2/N3/N10的差异也没有因局部跳变筛选而消失。这与融合末端受一致方向测距差异影响的解释相容，不能单凭本表确定硬件偏置；人工测量、坐标/高度和参考点假设的不确定度均未完全量化。没有将这些差值回填优化后再评分。\n',
        '## 静止漂移、残差与优化状态\n',
        table(['包','方案','起始静止首末位移 m','起始窗与候选点差 m','评价窗首末位移 m','评价窗X/Y std m'],[
            [s['run'],s['method'],
             f"{float(next(x for x in drift if x['run']==s['run'] and x['method']==s['method'] and x['phase']=='initial_stationary')['first_to_last_m']):.6f}",
             f"{float(next(x for x in drift if x['run']==s['run'] and x['method']==s['method'] and x['phase']=='initial_stationary')['difference_to_candidate_start_m']):.6f}",
             f"{s['endpoint']['first_to_last_drift_m']:.6f}",
             '/'.join(f'{v:.6f}' for v in s['endpoint']['xy_std_m'])] for s in summary]),
        '初始静止统计为[0,first_motion−0.5)，已有状态从2s开始，004023为9帧、005135为12帧。停止指令后2s起的中间静止窗、结束静止全窗和末窗均另列；指令idle不等于完全物理静止。起始窗与候选点差不是起点精度，因为候选点并未独立实测。\n',
        table(['包','方案','状态/测距因子数','nfev','status','cost','optimality'],[
            [s['run'],s['method'],f"{s['keyframes']}/{s['optimizer']['range_factors']}",
             s['optimizer']['optimizer_nfev'],s['optimizer']['optimizer_status'],
             f"{s['optimizer']['cost']:.6f}",f"{s['optimizer']['optimizer_optimality']:.6g}"] for s in summary if s['method']!='A']),
        '四组均status=2，ftol成功终止；保留原消息与梯度最优性指标。成功终止不代表全局最优，也不代表物理精度已验证。A是确定性传播。失败保存/标记路径有专门测试，本轮未发生优化失败。\n',
        table(['包','方案','节点','模型−中位数观测 残差中位数 m','绝对残差p95 m'],[
            [x['run'],x['method'],x['node'],f"{float(x['model_minus_measured_m_median']):.6f}",
             f"{float(x['absolute_residual_m_p95']):.6f}"] for x in residuals if x['phase']=='ALL']),
        '逐因子残差、伪Huber影响、各阶段/节点分布、odom between残差和先验残差均保存。上表模型−观测与几何诊断的观测−人工几何符号相反，参考也不同，不混用。\n',
        '## 时间覆盖与无解时段\n',
        table(['包','话题','>100ms接收间隔数','最大接收间隔 ms','最大header间隔 ms','>100ms header间隔数'],[
            [x['run'],x['topic'],x['receive_gaps_gt_100ms'],f"{1000*float(x['max_receive_gap_s']):.3f}",
             f"{1000*float(x['max_header_gap_s']):.3f}",x['header_gaps_gt_100ms']] for x in times
             if x['topic'] in ['/car2/uwb/ranges','/car2/odom','/car2/imu']]),
        '004023约93.425–93.854s存在共同接收停顿，此时相邻header仍约20/50/50ms。原因未知，不能认定硬件丢包；它发生在本轮评价窗之后，且与前段N10跳变分开登记。时间停顿未作为距离剔除理由。005135三个高频话题无>100ms接收间隔；正常约0.6s的电压话题不进入高频停顿列表。\n',
        'A/B/C的有效状态域分别为004023的2–97s、005135的2–93s（1s采样）；区间内部没有缺帧或失败解。B/C每帧都有4个墙测距因子，A无测距因子是设计行为。状态域外的[0,2)和末帧之后至bag末尾未输出状态，不据此声称全包连续定位可用。header连续也不证明绝无丢包或绝对时钟准确。详细插值支撑和覆盖见 `keyframe_coverage.csv`、`coverage_by_phase.csv`、`diagnostic_summary.json`。\n',
        'IMU仅作诊断：去初始5s陀螺零偏后的积分004023约−98.28°、005135约−98.52°；对应odom净角约−89.75°/−89.34°。可能同源且没有独立朝向真值，不据此校正轨迹。\n',
        '## 与旧报告的关系\n',
        table(['包','方案','旧助手陈述 m','本轮重建 m','差值 m'],[
            [s['run'],s['method'],f"{r.HISTORICAL[s['run']][['A','B','C'].index(s['method'])]:.6f}",
             f"{s['endpoint']['planar_difference_m']:.9f}",
             f"{s['endpoint']['planar_difference_m']-r.HISTORICAL[s['run']][['A','B','C'].index(s['method'])]:+.9f}"] for s in summary]),
        '旧报告新增剔除318/46，本轮322/45；旧称570轨迹行，本轮564。A舍入至6位与旧陈述一致，只能作为数值旁证，不能证明恢复了原文件。已知本轮使用明确的新筛选、公开的关键帧覆盖公式及旋转外参适配；旧源码/配置/窗口/MAD参数不可取回，无法逐项归因或声称精确复现。全程未为吻合旧数值调整权重、初值、窗或阈值。\n',
        '## 测试、软件与复现\n',
        f"实际运行{tests['tests_run']}项测试全部通过，无失败、错误或跳过：原有9项加新增20项。覆盖外参旋转、三维合成转弯、odom坐标系不变性、失败状态保留、窗口边界、全节点统一筛选、原始不变性、时间停顿不触发距离筛选、终点不泄漏、真实输入身份/账本守恒/B与C因子支撑/六组末窗再评价。`git diff --check`通过。详见 `tests/unittest.log`、`tests/test_report.json`；旧16项记录没有当作本轮测试证据。\n",
        table(['软件','实际版本'],[[k,str(v)] for k,v in manifest['software'].items()]),
        '完整命令见 `REPRODUCE.md` 和 `reproduce.sh`；复算必须使用新目录，禁止覆盖本轮产物。基线源码运行时哈希、测试源码哈希、冻结配置及所有输入哈希见 `input_source_hashes.json`、`baseline/source_hashes_at_run.json`、`tests/test_report.json`；包内SHA256SUMS覆盖实际文件本体。\n',
        '## 文件与Git改动清单\n',
        table(['文件/目录','用途'],[
            ['根HANDOFF.md','分阶段交接、实际Git现场、已完成及约束'],
            ['REPORT.md / METHOD_REVIEW.md / frozen_config.json','完整报告、实现核对、冻结配置'],
            ['input_manifest.json / input_source_hashes.json / evidence/','输入/源码哈希、原确认与索引、原配置和提交版分析器'],
            ['input_audit/','仅两包解码缓存及完整指令，非原始bag'],
            ['baseline/','六组结果、564行轨迹、完整筛选账本、聚合支撑、优化状态'],
            ['diagnostics/','几何残差、静止漂移、阶段/节点计数、时间/覆盖、因子和先验残差、历史对照、图'],
            ['tests/','真实测试日志、命令、状态和源码哈希'],
            ['REPRODUCE.md / reproduce.sh','独立新目录复现命令'],
            ['git/（审核包顶层）','最终HEAD、分支、完整status、tracked/staged diff、worktree信息'],
            ['PACKAGE_MANIFEST.json / SHA256SUMS.txt（包顶层）','逐文件本体哈希、改动/新增路径、排除原始bag声明']]),
        '修改已有 `tools/analyze_october_field_session.py`；新增根 HANDOFF、本轮独立结果目录，以及 rebuild/diagnose/report/package/test 五个 Oct18 脚本。原始bag、原备注、其他任务结果未修改。审核包同时包含改动diff与新增文件本体；无需依靠diff恢复未跟踪文件。\n',
        '## 后续审核建议\n',
        '当前可审核实现一致性和条件性对照，尚不能验收绝对定位精度。优先核实起点及base_footprint参考点关系，再用独立静态位置/不同记录验证测距系统性差异及权重；新校准或参数探索必须作为新的实验版本，不回填本次已评分数据。本轮到报告与审核包为止，不自动展开新分析、实车运行或合并。\n']
    (out/'REPORT.md').write_text('\n'.join(text),encoding='utf-8')
    print('REPORT_WRITTEN',out/'REPORT.md')


if __name__ == '__main__':
    main()
