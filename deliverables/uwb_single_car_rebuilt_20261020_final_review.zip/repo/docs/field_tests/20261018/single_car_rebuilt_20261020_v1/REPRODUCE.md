# 重建分析复现说明

本包是本轮重建产物，不是旧云端未提交工作恢复。只使用两份指定单车 bag；不运行 ROS 节点或实车。

## 环境与原始输入

代码以仓库完整 HEAD `9bf4f01fb778630006b52f7e6e3758f1ae68435e` 为基础。审核 ZIP 中 `repo/` 保存当前代码本体、配置和结果；`git/` 保存现场与补充 diff。保留现有仓库修改，不通过 reset/clean 恢复现场。需要从原始数据全量复现时，将本包工具代码用于一个可访问的完整仓库（prepare 会只读查询 Git 元数据）；无需提交这些工具。

Python 3.12.14，依赖见 `tools/requirements-october-modern.txt`。本轮已有可用环境 `/workspace/.uwb-cloud/offline-venv/bin/python`，无需重新安装或联网。

所需原始附件（不收入审核 ZIP）：

- `field_tests_20261018.tar.gz`：`c743dc90f3534812fc76073fdc0c594cb0e6cdd33ab82521d8c913fc4c90fcf9`
- `uwb_data_index_20261020.zip`：`371193a0bb542aa55a34486103058619b9adfd07a1c25b7dc2ced522a3d0d7ad`
- `cloud_inputs_SHA256SUMS.txt`：见 `input_manifest.json` 的附件哈希。

prepare 直接只读归档并在内存解码两包，不需要解压 bag。其他16个包只做哈希完整性核验，不分析消息。备注中的命令不执行。

## 本轮实际执行命令

在 `/workspace/uwb-coop-localization-ros1`：

```bash
/workspace/.uwb-cloud/offline-venv/bin/python tools/rebuild_oct18_single_car.py prepare --archive /workspace/attachments/c6993ace-655b-4c24-8898-d8ceeace3f72/field_tests_20261018.tar.gz --index /workspace/attachments/c98598ed-15ee-4c56-b91b-e1b4c015c970/uwb_data_index_20261020.zip --sums /workspace/attachments/7e1eeebb-c2ae-4059-b7fd-fb0c5b3f32c8/cloud_inputs_SHA256SUMS.txt --output docs/field_tests/20261018/single_car_rebuilt_20261020_v1
/workspace/.uwb-cloud/offline-venv/bin/python -u tools/rebuild_oct18_single_car.py baseline --output docs/field_tests/20261018/single_car_rebuilt_20261020_v1
/workspace/.uwb-cloud/offline-venv/bin/python -u tools/diagnose_oct18_rebuild.py --output docs/field_tests/20261018/single_car_rebuilt_20261020_v1
```

基线和诊断标准输出分别保存为 `baseline_console.txt`、`diagnostics_console.txt`。prepare 的关键信息和指令边界保存在 `input_manifest.json`。

测试在仓库 `tools/` 中执行：

```bash
UWB_REBUILD_RUN=/workspace/uwb-coop-localization-ros1/docs/field_tests/20261018/single_car_rebuilt_20261020_v1 /workspace/.uwb-cloud/offline-venv/bin/python -m unittest -v test_october_field_session test_oct18_rebuild
```

实际29项全部通过，日志 `tests/unittest.log`，结构化记录 `tests/test_report.json`；源码哈希包含于记录。测试只对小型合成数据求解；真实产物测试只复核身份、聚合和评价，不重新优化两份真实 bag。

最终报告生成：

```bash
/workspace/.uwb-cloud/offline-venv/bin/python tools/report_oct18_rebuild.py --output docs/field_tests/20261018/single_car_rebuilt_20261020_v1
/workspace/.uwb-cloud/offline-venv/bin/python tools/package_oct18_rebuild.py --run docs/field_tests/20261018/single_car_rebuilt_20261020_v1 --stage final_review
```

报告、prepare、baseline、diagnostics 和封包均拒绝覆盖已存在的同名阶段产物。以上是已执行步骤的记录，不应在当前完整结果目录再次执行。

## 在独立新目录复现

`reproduce.sh` 接收 archive/index/checksum 三个路径及一个**尚不存在的新目录**，完整复算 prepare、baseline、diagnostics 与29项测试；不提交或修改原始数据，也不覆盖本次结果。可通过 `UWB_PYTHON` 选择已有 Python 环境。

```bash
UWB_PYTHON=/workspace/.uwb-cloud/offline-venv/bin/python bash docs/field_tests/20261018/single_car_rebuilt_20261020_v1/reproduce.sh /path/field_tests_20261018.tar.gz /path/uwb_data_index_20261020.zip /path/cloud_inputs_SHA256SUMS.txt /workspace/work/uwb_reproduction_fresh
```

本轮没有执行这个全量复现脚本，以免重复启动六组真实数据分析；其各条命令已按阶段执行并通过检查。软件/线性代数库差异可能产生末位浮点变化，比较时应同时核对配置、输入/源码哈希、终止状态和样本数。

## 无原始bag时的审核

解包即可检查 REPORT、配置、命令边界、全部账本、轨迹、诊断及测试证据。`input_audit/*_decoded.json.gz` 是仅两包的已解码派生数据，不是原始 bag。可运行真实产物测试，无需原始 bag。不能仅凭派生缓存认证原始数据身份，原始身份仍应由审核者持有的附件哈希交叉核对。

## 审核包完整性

包外 `.zip.sha256` 是 ZIP 本身的 SHA-256；包内 `SHA256SUMS.txt` 覆盖每个文件，包含新增文件本体。封包脚本执行 ZIP CRC 检查、逐成员哈希检查、重复成员检查、原始 bag 扩展名及文件头排除。三个阶段检查点的包名及哈希另见 `checkpoints.json`，不把检查点压缩包嵌套入最终包。
