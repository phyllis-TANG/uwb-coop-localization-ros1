import csv
import hashlib
import json
from pathlib import Path
import zipfile
from collections import Counter

root = Path(__file__).resolve().parent / 'data_inventory_20261020'
out = root / 'segmented_review'
data = json.loads((out / 'segmented_summary.json').read_text(encoding='utf-8'))
bins = list(csv.DictReader((out / 'one_second_ranges.csv').open(encoding='utf-8-sig', newline='')))
text = '''# 两份单车L形包：分段测距与消息时间审计

整理日期：2026-10-20。仅重新读取原始bag、计算统计并生成派生文件；没有运行融合、仿真或实车实验。时间以各bag首条记录为0，均为录包接收时间，区间右端不包含。

## 当前使用结论

1. 两包均保留。005135是用户确认正常完成的录制，但N10仍有局部大幅跳变；不能把“录制正常”当作“所有测距可靠”。
2. 004023的N10起始静止窗口和第一段直行都有明显波动；005135的N10最突出波动在第一段直行。暂不确定硬件、传播环境或驱动中的具体原因。
3. 004023末段有跨UWB/odom/IMU的共同接收间隔；这与N10前段距离跳变分别记录，不能归为同一已证实原因。005135的这三个话题未发现超过100ms的相邻接收间隔。
4. 005135可作正常完成录制的主候选，004023可作N10波动较多的对照候选；本对照尚不证明两次精确重走同一路径，也不构成算法精度结论。

## 运动阶段

分段依据控制指令，并用odom检查相应路程/航向。第二段前进包含小角速度纠偏，不把它拆称为多次主转弯。

| 包 | 阶段 | 起止时间，s | 阶段内odom路程，m | odom航向增量，度 |
|---|---|---:|---:|---:|
'''
macro_data = []
for b in data['bags']:
    seg = b['segments']
    groups = [('运动前（odom静止）',[0,1]), ('第一段前进',[2]), ('第一段后停止指令',[3]), ('主转弯',[4]), ('转弯后停止指令',[5]), ('第二段前进，含纠偏',list(range(6,11))), ('结束静止阶段',[11,12])]
    for label, ids in groups:
        ss = [seg[i] for i in ids]
        lo, hi = ss[0]['start_s'], ss[-1]['end_s']
        path = sum(s['odom_path_m'] for s in ss)
        yaw = sum(s['odom_yaw_change_deg'] for s in ss)
        text += f"| {b['run']} | {label} | {lo:.3f}–{hi:.3f} | {path:.4f} | {yaw:.2f} |\n"
        macro_data.append({'run':b['run'],'phase':label,'start_s':lo,'end_s':hi,'odom_path_m':path,'odom_yaw_change_deg':yaw})
text += '''
停止指令刚发出后仍可能有少量odom变化，因此不能把每个idle区间都称为实际完全静止。两包开始部分和末尾部分没有持续cmd消息，详细表记为unknown，但这些时段odom仍有记录；unknown不代表包损坏。阶段里程按相邻odom位移归入后一个样本所在段，边界步长可能跨段；整包分段里程之和与原始整包统计核对一致。

## N10明显波动窗口：候选核查窗口，不是完整异常标签

| 包 | 窗口，s | N10标准差，m | 相邻有效读数变化的95%分位，m | 指令状态 |
|---|---:|---:|---:|---|
'''
for b in data['bags']:
    for r in b['n10_highest_std_1s_bins'][:5]:
        text += f"| {b['run']} | {r['start_s']}–{r['end_s']:.0f} | {r['std_m']:.4f} | {r['consecutive_delta_p95_m']:.4f} | {r['overlapping_states']} |\n"
text += '\n最大的短时N10相邻读数变化：\n\n'
for b in data['bags']:
    j = b['largest_consecutive_range_changes']['node_10'][0]
    text += f"- {b['run']}：t={j['start_s']:.6f}→{j['end_s']:.6f}s，{j['previous_m']:.3f}→{j['current_m']:.3f}m，接收间隔{j['dt_s']*1000:.2f}ms，变化{j['absolute_delta_m']:.3f}m。\n"
text += '''
如此短间隔中的米级距离变化不能由约0.045m/s的正常直行解释，支持观测或其生成链路存在不一致；但没有独立测距真值，尚不能确定相邻两值中哪个正确、具体故障来源或完整异常区间。表中只列波动最大的1秒窗口，未列出的窗口不自动视为可靠。

## 各墙节点短时变化对照

| 包 | 节点 | 全包最大相邻读数变化，m | 对应接收间隔，ms | 变化结束时间，s |
|---|---|---:|---:|---:|
'''
for b in data['bags']:
    for n in (2,3,8,10):
        j = b['largest_consecutive_range_changes'][f'node_{n}'][0]
        text += f"| {b['run']} | N{n} | {j['absolute_delta_m']:.3f} | {j['dt_s']*1000:.2f} | {j['end_s']:.3f} |\n"
text += '\n该对照不要求已知全局起点，不把全包运动导致的正常距离变化当作噪声；相邻变化只统计接收间隔不超过100ms的有效读数。其他节点也不因波动较小而自动无偏。\n\n## 接收间隔与消息头间隔\n\n| 包 | 话题 | >100ms接收间隔数量 | 最大接收间隔，ms | 该处消息头间隔，ms | 起止时间，s |\n|---|---|---:|---:|---:|---:|\n'
for b in data['bags']:
    for topic in ('/car2/uwb/ranges','/car2/odom','/car2/imu'):
        gg = [g for g in b['receive_gaps_over_100ms'] if g['topic']==topic]
        if gg:
            g = max(gg,key=lambda x:x['receive_gap_ms'])
            text += f"| {b['run']} | {topic} | {len(gg)} | {g['receive_gap_ms']:.2f} | {g['header_gap_ms']:.2f} | {g['start_s']:.3f}–{g['end_s']:.3f} |\n"
        else: text += f"| {b['run']} | {topic} | 0 | — | — | — |\n"
text += '''
004023最明显的共同接收停顿在约93.425–93.854s，此时已在结束静止阶段。相邻消息头仍分别约20ms（UWB）和50ms（odom/IMU），更符合接收、传输或记录侧批量积压的表现；这是推断，现有记录不能定位具体环节，也不能据此证明时钟绝对正确或完全没有丢包。N10前段跳变与该末段共同停顿在时间上分开。

100ms仅为本轮列出接收间隔的审计阈值，不是已验证的丢包判据。正常约0.6s发布一次的电压话题不纳入此表，避免误报低频话题。

## 方法和边界

- 控制分类：线速度绝对值>0.005m/s记前进，角速度绝对值>0.04rad/s记转向，两者同时满足记mixed；都不满足记idle。无新cmd超过0.5s记unknown。阈值仅用于整理分段，不用于位置优化。
- 一秒窗口以bag首条记录为原点；表中std采用总体标准差。边界混合状态在overlapping_states列保留，短于1秒的末窗口也保留。波动窗口排序要求至少10条有效观测。
- 有效测距指同一帧的相应节点条目唯一、有限且大于零。缺失/重复/非有限值与距离波动分开记录。
- 没有用终点调参，没有套用其他日期的墙节点偏差；人工终点和起点候选状态保持U001/U002记录。
- 未生成硬性异常删选掩码，未删除N10或整包数据。短时跳变统计也不能检出稳定偏置。

## 文件

- segments.csv：控制状态分段、odom变化及每节点统计。
- one_second_ranges.csv：每秒每节点有效数、标准差、相邻读数变化。
- receive_gaps_over_100ms.csv：UWB、odom、IMU的接收间隔事件及对应消息头间隔。
- segmented_summary.json：完整分段、候选波动窗口和最大相邻变化事件。

下一步可在这些固定分段上评估测距筛选方案，并保留原始版作为对照。进入定位精度比较前，应单列候选起点及天线外参假设；不需要为当前时间/测距质量审计重新采集数据。
'''
(out / 'README.md').write_text(text,encoding='utf-8')
with (out/'phase_index.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(macro_data[0]));w.writeheader();w.writerows(macro_data)

index_path=root/'dataset_index.json'
index=json.loads(index_path.read_text(encoding='utf-8'))
for b in index['bags']:
    if b['record_id'] in ('B054','B055'):
        msg='分段审计：'+('正常完成录制，但N10约20–22s有明显局部跳变；三个高频话题无>100ms接收间隔' if b['record_id']=='B054' else 'N10在运动前及第一段直行波动；末段约93.425–93.854s有跨话题共同接收停顿')
        b['review_note'] += '；'+msg
        b['quality_audit']={'report':'segmented_review/README.md','source':'原始bag只读分段统计','conclusion':msg,'global_start_required':False}
index_path.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (root/'dataset_index.csv').open(encoding='utf-8-sig',newline='') as f:
    rd=csv.DictReader(f);fields=rd.fieldnames;rows=list(rd)
notes={b['record_id']:b['review_note'] for b in index['bags']}
for row in rows:row['review_note']=notes[row['record_id']]
with (root/'dataset_index.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
for name in ('README.md','两包数据质量对照.md'):
    path=root/name
    value=path.read_text(encoding='utf-8')
    value+='\n## 后续分段审计\n\n已完成[分段测距与消息时间审计](segmented_review/README.md)：005135虽正常完成录制，N10仍有局部跳变；004023的N10前段波动与末段共同接收停顿分别登记。\n'
    path.write_text(value,encoding='utf-8')

# Check partitions and source identity against already verified full-bag inventory.
raw_stats=json.loads((root/'raw_statistics.json').read_text(encoding='utf-8'))['records']
for b in data['bags']:
    raw=next(r for r in raw_stats if r['file'].endswith(b['file']))
    segments=b['segments']
    assert abs(sum(s['duration_s'] for s in segments)-b['duration_s'])<1e-8
    assert abs(sum(s['odom_path_m'] for s in segments)-raw['odom']['/car2/odom']['path_m'])<1e-8
    for n in (2,3,8,10):
        assert sum(next(r for r in s['ranges'] if r['node']==n)['valid'] for s in segments)==raw['uwb']['/car2/uwb/ranges']['links'][f'node_{n}']['valid']
    assert raw['sha256']==b['sha256']
zip_path=root.parent/'uwb_data_index_20261020.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(root.rglob('*')):
        if f.is_file():z.write(f,f.relative_to(root))
    for name in ('segment_oct18_lshape.py','publish_segmented_review.py'):
        z.write(root.parent/name,'audit_scripts/'+name)
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
print('Report and inventory updated; segment durations, odom totals, link counts, source SHA and ZIP integrity checked.')
