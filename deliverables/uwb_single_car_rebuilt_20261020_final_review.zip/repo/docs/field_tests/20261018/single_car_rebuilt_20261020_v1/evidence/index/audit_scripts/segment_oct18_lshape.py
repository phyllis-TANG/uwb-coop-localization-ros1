"""Read two original bag members in memory; write derived audit artifacts only."""
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import sys
import tarfile
import zipfile
from collections import defaultdict

sys.path.insert(0, r'C:\Users\Lenovo\AppData\Local\Temp\uwb-readonly-review-20261020\deps')
import numpy as np
from rosbags.highlevel import AnyReader

ROOT = Path(__file__).resolve().parent / 'data_inventory_20261020'
OUT = ROOT / 'segmented_review'
OUT.mkdir(exist_ok=True)
INDEX = json.loads((ROOT / 'dataset_index.json').read_text(encoding='utf-8'))
ARCHIVE = Path(r'C:\Users\Lenovo\AppData\Local\Temp\codex-file-preview-hVGob7\field_tests_20261018.tar.gz')

class MemoryBag:
    suffix = '.bag'
    def __init__(self, name, data): self.name, self.data = name, data
    def exists(self): return True
    def open(self, mode='rb'):
        if mode != 'rb': raise ValueError('read only')
        return io.BytesIO(self.data)
    def __str__(self): return self.name

def write_csv(name, rows):
    if not rows: return
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with (OUT / name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fields)
        w.writeheader()
        w.writerows(rows)

def stat(x):
    a = np.asarray(x, dtype=float)
    return {'count': len(a), 'median': float(np.median(a)) if len(a) else None,
            'std': float(np.std(a)) if len(a) else None,
            'p95': float(np.quantile(a, .95)) if len(a) else None,
            'max': float(np.max(a)) if len(a) else None}

def classify(v, w):
    lin, rot = abs(v) > .005, abs(w) > .04
    return 'mixed' if lin and rot else 'straight' if lin else 'turn' if rot else 'idle'

all_segments, all_bins, all_gaps, summary = [], [], [], []
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    members = {Path(m.name).name: m for m in tar.getmembers() if m.isfile()}
    for run in ('004023', '005135'):
        b = next(b for b in INDEX['bags'] if b['filename_date'] == '20261018' and b['filename_run_id'] == run)
        raw = tar.extractfile(members[b['filename']]).read()
        assert hashlib.sha256(raw).hexdigest() == b['sha256']
        times, odom, commands, uwb = defaultdict(list), [], [], []
        with AnyReader([MemoryBag(b['filename'], raw)]) as reader:
            start = reader.start_time
            duration = reader.duration / 1e9
            for c, ns, buf in reader.messages():
                t = (ns - start) / 1e9
                msg = reader.deserialize(buf, c.msgtype)
                h = getattr(msg, 'header', None)
                ht = ((h.stamp.sec * 10**9 + h.stamp.nanosec - start) / 1e9) if h is not None else None
                times[c.topic].append((t, ht))
                if c.topic.endswith('/cmd_vel'):
                    commands.append((t, classify(msg.linear.x, msg.angular.z)))
                elif c.topic.endswith('/odom'):
                    p, q = msg.pose.pose.position, msg.pose.pose.orientation
                    yaw = math.atan2(2 * (q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))
                    odom.append((t, p.x, p.y, yaw))
                elif c.topic.endswith('/ranges'):
                    grouped = defaultdict(list)
                    for r in msg.ranges: grouped[str(r.anchor_id)].append(float(r.range))
                    vals = {k:v[0] for k,v in grouped.items() if len(v)==1 and math.isfinite(v[0]) and v[0]>0}
                    uwb.append((t, vals))
        # Command state is held at most 0.5s; longer unobserved periods are unknown.
        edges = {0., duration}
        for t, _ in commands:
            edges.add(t)
            edges.add(min(duration, t + .5))
        edges = sorted(edges)
        states, j = [], -1
        for lo, hi in zip(edges[:-1], edges[1:]):
            while j + 1 < len(commands) and commands[j+1][0] <= lo + 1e-10: j += 1
            state = commands[j][1] if j >= 0 and lo - commands[j][0] < .5 - 1e-9 else 'unknown'
            if states and states[-1][2] == state:
                states[-1][1] = hi
            else: states.append([lo, hi, state])
        a = np.asarray(odom)
        yaw = np.unwrap(a[:,3])
        ds = np.r_[0, np.linalg.norm(np.diff(a[:,1:3], axis=0), axis=1)]
        dyaw = np.r_[0, np.degrees(np.diff(yaw))]
        for topic, values in times.items():
            if not topic.endswith(('/imu', '/odom', '/ranges')):
                continue
            for (ta, ha), (tb, hb) in zip(values[:-1], values[1:]):
                if tb - ta > .1:
                    all_gaps.append({'run':run, 'topic':topic, 'start_s':ta, 'end_s':tb, 'receive_gap_ms':(tb-ta)*1000,
                                     'header_gap_ms':(hb-ha)*1000 if ha is not None and hb is not None else None})
        def range_rows(lo, hi):
            frames = [(t,v) for t,v in uwb if lo <= t < hi]
            result = []
            for n in (2,3,8,10):
                seq = [(t,v[f'node_{n}']) for t,v in frames if f'node_{n}' in v]
                v = [x[1] for x in seq]
                # Consecutive differences only for observations no farther than 0.1s apart.
                jumps = [abs(y[1]-x[1]) for x,y in zip(seq[:-1],seq[1:]) if 0 < y[0]-x[0] <= .1]
                st, jt = stat(v), stat(jumps)
                result.append({'node':n, 'frames':len(frames), 'valid':len(v), 'valid_fraction':len(v)/len(frames) if frames else None,
                               'median_m':st['median'], 'std_m':st['std'], 'consecutive_delta_median_m':jt['median'],
                               'consecutive_delta_p95_m':jt['p95'], 'consecutive_delta_max_m':jt['max']})
            return result
        segment_details = []
        for i, (lo, hi, state) in enumerate(states):
            mask = (a[:,0]>=lo) & (a[:,0]<hi)
            seg = {'run':run, 'segment':i+1, 'state':state, 'start_s':lo, 'end_s':hi, 'duration_s':hi-lo,
                   'odom_path_m':float(ds[mask].sum()), 'odom_yaw_change_deg':float(dyaw[mask].sum())}
            seg['ranges'] = range_rows(lo,hi)
            segment_details.append(seg)
            all_segments.extend([{**{k:v for k,v in seg.items() if k!='ranges'}, **r} for r in seg['ranges']])
        run_bins = []
        for lo in range(math.ceil(duration)):
            hi = min(float(lo+1), duration)
            mid = (lo+hi)/2
            state = next(s[2] for s in states if s[0] <= mid < s[1])
            overlapping = [s[2] for s in states if s[0]<hi and s[1]>lo]
            for r in range_rows(lo,hi):
                row = {'run':run, 'start_s':lo, 'end_s':hi, 'state_at_midpoint':state, 'overlapping_states':';'.join(dict.fromkeys(overlapping)), **r}
                run_bins.append(row)
        all_bins.extend(run_bins)
        n10bins = [r for r in run_bins if r['node']==10 and r['valid']>=10]
        highest = sorted(n10bins, key=lambda r:r['std_m'], reverse=True)[:10]
        top_jumps = sorted(n10bins, key=lambda r:r['consecutive_delta_p95_m'] if r['consecutive_delta_p95_m'] is not None else -1, reverse=True)[:10]
        jumps_by_node = {}
        for node in (2,3,8,10):
            seq = [(t,v[f'node_{node}']) for t,v in uwb if f'node_{node}' in v]
            events = [{'start_s':x[0], 'end_s':y[0], 'dt_s':y[0]-x[0], 'previous_m':x[1], 'current_m':y[1], 'absolute_delta_m':abs(y[1]-x[1])}
                      for x,y in zip(seq[:-1],seq[1:]) if 0 < y[0]-x[0] <= .1]
            jumps_by_node[f'node_{node}'] = sorted(events, key=lambda e:e['absolute_delta_m'], reverse=True)[:10]
        summary.append({'run':run, 'file':b['filename'], 'sha256':b['sha256'], 'duration_s':duration,
                        'segments':segment_details, 'n10_highest_std_1s_bins':highest, 'n10_highest_delta_p95_1s_bins':top_jumps,
                        'largest_consecutive_range_changes':jumps_by_node,
                        'receive_gaps_over_100ms':[g for g in all_gaps if g['run']==run]})

write_csv('segments.csv', all_segments)
write_csv('one_second_ranges.csv', all_bins)
write_csv('receive_gaps_over_100ms.csv', all_gaps)
(OUT/'segmented_summary.json').write_text(json.dumps({'method':{'time':'bag receipt relative to first message', 'command_threshold_linear_m_s':.005, 'command_threshold_angular_rad_s':.04, 'command_max_hold_s':.5, 'gap_listing_threshold_s':.1, 'delta_max_observation_separation_s':.1, 'std_ddof':0, 'labels':'commanded state, checked separately against odometry; not physical truth'}, 'bags':summary}, ensure_ascii=False,indent=2)+'\n', encoding='utf-8')
for r in summary:
    print(json.dumps({'run':r['run'], 'segments':len(r['segments']),
                      'n10_top_std':[(b['start_s'],round(b['std_m'],4)) for b in r['n10_highest_std_1s_bins'][:3]],
                      'n10_top_jump':r['largest_consecutive_range_changes']['node_10'][0],
                      'gap_count':len(r['receive_gaps_over_100ms'])}, ensure_ascii=True))
