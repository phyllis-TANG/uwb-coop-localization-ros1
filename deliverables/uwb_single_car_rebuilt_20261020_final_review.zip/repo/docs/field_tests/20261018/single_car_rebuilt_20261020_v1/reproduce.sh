#!/usr/bin/env bash
# Explicitly opt-in full offline reproduction in a fresh directory.
set -euo pipefail
if [ "$#" -ne 4 ]; then
    printf '%s\n' 'Usage: bash reproduce.sh ARCHIVE INDEX_ZIP CHECKSUMS NEW_OUTPUT_DIRECTORY' >&2
    exit 2
fi
uwb_python="${UWB_PYTHON:-python3}"
uwb_archive="$(realpath "$1")"
uwb_index="$(realpath "$2")"
uwb_sums="$(realpath "$3")"
uwb_run_output="$(realpath -m "$4")"
uwb_repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../.." && pwd)"
if [ -e "$uwb_run_output" ]; then
    printf '%s\n' 'Output already exists; choose a new directory.' >&2
    exit 2
fi
cd "$uwb_repo_root"
"$uwb_python" tools/rebuild_oct18_single_car.py prepare --archive "$uwb_archive" --index "$uwb_index" --sums "$uwb_sums" --output "$uwb_run_output"
"$uwb_python" -u tools/rebuild_oct18_single_car.py baseline --output "$uwb_run_output" > "$uwb_run_output/baseline_console.txt" 2>&1
"$uwb_python" -u tools/diagnose_oct18_rebuild.py --output "$uwb_run_output" > "$uwb_run_output/diagnostics_console.txt" 2>&1
mkdir -p "$uwb_run_output/tests"
cd tools
UWB_REBUILD_RUN="$uwb_run_output" "$uwb_python" -m unittest -v test_october_field_session test_oct18_rebuild > "$uwb_run_output/tests/unittest.log" 2>&1
printf '%s\n' "Reproduction and tests complete: $uwb_run_output"
