# UWB 10月18日两包单车：重建分析

本轮是依据已提交代码、原始数据和冻结说明重新计算；旧任务未提交代码和结果未恢复。禁止把本轮称为旧任务文件恢复，禁止调整参数去凑历史终点数值。

## 当前阶段

输入与配置核对、两包 A/B/C 基线计算、诊断和必要测试、最终报告均已完成。审核包由封包脚本生成并逐成员校验；后续等待指导窗口审核，不继续扩大分析范围。

## Git 现场与目录

- 实际仓库 `/workspace/uwb-coop-localization-ros1`，分支 `work`。
- 起始完整 HEAD `9bf4f01fb778630006b52f7e6e3758f1ae68435e`，起始 status 干净。
- 本轮独立目录 `docs/field_tests/20261018/single_car_rebuilt_20261020_v1/`。
- 附件与临时工作 `/workspace/attachments/`、`/workspace/work/uwb_rebuild_20261020/`。
- 检查点 `/workspace/output/uwb_rebuilt_20261020/`。
- 当前修改/新增：根 HANDOFF、本轮独立结果目录、`tools/rebuild_oct18_single_car.py`、`tools/package_oct18_rebuild.py`、`tools/analyze_october_field_session.py`（可选天线外参和完整优化状态；旧调用默认零偏移）。后续新增诊断与测试脚本。每个审核包内含实际 Git status、diff 和文件本体。

## 已完成

附件外部 SHA-256 校验通过，索引 ZIP CRC 通过，归档内18个 bag 哈希均与内置清单一致。实际只分析 004023/005135。完整阅读《云端下一轮指令.md》及 U001/U002，原文保留在本轮 evidence 目录。根 HANDOFF、旧结果目录、旧新增两脚本和分析器未提交修改均未找到；现有 two_car_graph 结果属于其他任务。

从原始指令重新解析两段前进及停止边界，评价区间固定为最后一段停止后 `[2,7)` 秒。精确纳秒解码边界与消息数见 `input_manifest.json`，完整命令见 `input_audit/*_commands.csv`。

## 冻结配置与限制

见 `frozen_config.json` 和 `METHOD_REVIEW.md`。墙节点及权重沿用10月17日提交配置；距离额外偏差全部为零，未沿用 P1 校正。起点 `[2,2,0.2]` 是候选；起始朝 +Y、终点为天线中心是用户确认。采用水平外参 `[0.12,-0.08]`，假设几何中心等于 base_footprint，按 yaw 旋转后求天线。B/C 仅改变筛选。旧 C 源码、窗口、MAD 参数不明，本轮 C 为新探索版本，参数运行前已冻结。人工终点只用于评价/几何诊断。

## 已运行与下一步

已运行 `tools/rebuild_oct18_single_car.py prepare`（附件路径保存在 manifest）。接下来：

```bash
cd /workspace/uwb-coop-localization-ros1
/workspace/.uwb-cloud/offline-venv/bin/python tools/rebuild_oct18_single_car.py baseline --output docs/field_tests/20261018/single_car_rebuilt_20261020_v1
```

上述基线命令已完成，日志 `baseline_console.txt`。四次优化均以 ftol 条件成功终止（004023 B/C 各11次函数评价，005135 B/C 各12次）；状态、cost、optimality 均保留。A 是确定性传播，无优化。共564行轨迹，每个方案的末窗均5个关键帧。

本轮终点平面差（m）：004023 A/B/C = 0.285498852 / 0.557466303 / 0.557277248；005135 = 0.245666034 / 0.642611505 / 0.642622185。仅条件性重建结果，未见融合比纯 odom 更接近这两个人工终点。B/C 几乎相同，需结合稳定几何残差解释，不能据此称筛选已消除偏差。

已运行 `tools/diagnose_oct18_rebuild.py --output docs/field_tests/20261018/single_car_rebuilt_20261020_v1`；日志与全部表格在独立目录。运行原有9项及新增20项科学回归/真实产物一致性测试，实际29项全部通过（无跳过），详情 `tests/unittest.log` 和 `tests/test_report.json`；`git diff --check` 通过。这是本轮实际验证，与旧报告16项无关。

筛选新增剔除：004023共322条（N2/N3/N8/N10 = 5/0/102/215），005135共45条（9/0/7/29），全部来自本轮统一 Hampel；物理下界未触发。完整账本覆盖38520个帧×节点槽位，保留缺失、原值、header/接收时刻及原因。

末窗原始测距中位数减冻结几何距离，N2/N3/N8/N10：004023 = +0.443681/+0.205990/+0.273514/+0.478750m；005135 = +0.470455/+0.202424/+0.321084/+0.544874m。这些是评价诊断，未回填校准。004023的N8末窗仍有波动，C剔除该窗23条后其中位数差仍+0.266514m。

004023三个高频话题 >100ms 接收间隔数 UWB/odom/IMU = 19/20/20，最大约0.429s；header均无>100ms间隔。005135三者均无此接收间隔。单独记录为时间现象，原因未知，不视作距离筛选理由。四组融合在全部关键帧均有4个测距因子，未发现内部无解段；首尾关键帧外区域不输出状态，边界见覆盖表。

新增 `tools/diagnose_oct18_rebuild.py`、`tools/test_oct18_rebuild.py`、`tools/report_oct18_rebuild.py`；均随包保留本体。最终 `REPORT.md`、`REPRODUCE.md`、`reproduce.sh`、`input_source_hashes.json` 已完成。复现脚本通过 `bash -n` 和仓库路径解析检查；本轮没有执行全量复现脚本，以免重复运行真实数据分析。

最终封包命令：

```bash
/workspace/.uwb-cloud/offline-venv/bin/python tools/package_oct18_rebuild.py --run docs/field_tests/20261018/single_car_rebuilt_20261020_v1 --stage final_review
```

四阶段包保存到 `/workspace/output/uwb_rebuilt_20261020/`，前三阶段 identities 另见 `checkpoints.json`；最终包名 `uwb_single_car_rebuilt_20261020_final_review.zip`。包外 `.zip.sha256` 与 `.verification.json` 给出实际 ZIP 哈希和读取校验结果，不在包内循环嵌入包自身哈希。审核包包含全部本轮新增/修改文件本体、配置、报告、解码派生数据、源码/输入哈希、Git状态及补充diff，不含原始bag。原始已提交分析器另保存于 `evidence/committed_source/`。

后续：先审核条件性结果、参考点假设和系统性几何差异；本轮不自行展开新校准、调参、实车或合并。

## 安全与持久化

不操作实车，不初始化 ROS 节点；不修改原始 bag 和备注；不 reset、clean、丢弃修改、提交、推送或合并。所有派生结果在新目录，阶段输出存在即拒绝覆盖。检查点含新增文件本体、源代码及哈希，排除原始 bag；封包完成后检查 CRC、逐文件哈希并提供包 SHA-256。
