"""Post-run independent counts and byte bindings; no estimator/results tuning."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/work/uwb-geometry-correction-20261101')
MATRIX=ROOT/'matrix-v1'
ANALYSIS=ROOT/'analysis-v1'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def main():
    idx=read(MATRIX/'RUN_INDEX.json')
    assert idx['status']=='DONE' and len(idx['cells'])==48
    assert idx['code_commit']=='63701fee9067d3517c4db9dde93a15891fc8335e' and not idx['worktree_dirty']
    for name,h in idx['files'].items():assert sha(MATRIX/name)==h,name
    lock=read(REPO/'docs/research/geometry_correction_20261101_private/SOURCE_LOCK.json')
    assert lock==idx['source_sha256']
    original=0
    for name,h in lock.items():
        assert sha(REPO/name)==h,name
        if not name.startswith('tools/geometry_correction_20261101/'):
            old=subprocess.check_output(['git','show','b7af016b09e5717b718d9251341706fc33aa6f46:'+name],cwd=REPO)
            assert hashlib.sha256(old).hexdigest()==h,name
            original+=1
    with (ANALYSIS/'PER_CONFIGURATION.csv').open() as f:reported=list(csv.DictReader(f))
    counts=[];failures=[];statuses={};costs=[];readbacks={};expected={(s,g,p,m) for s in range(20261101701,20261101705) for g in ('G1','G2') for p in ('raw','historical') for m in ('M2','M3','M3W025')}
    actual=set()
    for c in idx['cells']:
        key=c['seed'],c['geometry'],c['processing'],c['method'];assert key not in actual;actual.add(key)
        run=MATRIX/c['run'];meta=read(run/'run.json');inp=MATRIX/c['input']
        assert meta['code_commit']==idx['code_commit'] and not meta['worktree_dirty']
        assert meta['source_sha256']==lock and meta['input_sha256']==sha(inp/'events.jsonl.gz') and meta['config_sha256']==sha(inp/'config.json')
        assert meta['estimator_inputs']==['events','config']
        for name,h in meta['outputs'].items():assert sha(run/name)==h
        costs.append({k:meta[k] for k in ('elapsed_s','process_cpu_s','process_peak_rss_kib')})
        rb=read(MATRIX/(f'{key[0]}-{key[1]}-{key[2]}-{key[3]}-READBACK.json'));assert rb['status']=='PASS'
        for name,n in rb['counts'].items():readbacks[name]=readbacks.get(name,0)+n
        with gzip.open(run/'updates.jsonl.gz','rt') as f:journal={int((r['state_epoch_ns']-1790000000000000000)//10**9):r for r in map(json.loads,f)}
        with (run/'published.csv').open() as f:rows=list(csv.DictReader(f))
        assert len(rows)==180
        for car in ('car1','car2'):
            seq=[r for r in rows if r['vehicle_id']==car and 6<=(int(r['state_epoch_ns'])-1790000000000000000)//10**9<=95]
            assert len(seq)==90
            accepted=sum(r['accepted_graph']=='True' and r['valid']=='True' for r in seq)
            finite=sum(r['finite_output']=='True' for r in seq)
            failed=sum('failed' in journal[(int(r['state_epoch_ns'])-1790000000000000000)//10**9]['status'] or 'error' in journal[(int(r['state_epoch_ns'])-1790000000000000000)//10**9]['status'] for r in seq)
            rec=dict(seed=key[0],geometry=key[1],processing=key[2],method=key[3],car=car,scheduled=90,accepted=accepted,finite=finite,failed=failed,unknown_or_not_accepted=90-accepted)
            counts.append(rec)
            rep=next(v for v in reported if (int(v['seed']),v['geometry'],v['processing'],v['method'],v['car'])==(*key,car))
            assert (accepted,finite,failed,90-accepted)==tuple(int(rep[k]) for k in ('accepted_count','finite_count','failed_count','unknown_or_not_accepted_count'))
        for t,r in journal.items():
            statuses[r['status']]=statuses.get(r['status'],0)+1
            if 'failed' in r['status'] or 'error' in r['status']:failures.append(dict(seed=key[0],geometry=key[1],processing=key[2],method=key[3],time_s=t,status=r['status']))
    assert actual==expected
    assert len(failures)==len(read(ANALYSIS/'FAILURES.json'))
    pairing=[read(MATRIX/(str(s)+'-PAIRING.json')) for s in range(20261101701,20261101705)]
    assert all(v['status']=='PASS' for v in pairing)
    result=dict(status='PASS',exact_optimizer_cells=48,original_PR91_files_byte_identical=original,source_files_locked=len(lock),cell_vehicle_coverage_rows=counts,publication_statuses=statuses,failed_publications=failures,readback_totals=readbacks,pairing_random_arrays=sum(v['random_arrays'] for v in pairing),pairing_initializers=sum(v['initializers_independently_checked'] for v in pairing),measurement_geometry_checks=sum(v['measurement_geometry_checks'] for v in pairing),estimator_input_truth_isolated=True,optimizer_cpu_s=sum(v['process_cpu_s'] for v in costs),optimizer_elapsed_s=sum(v['elapsed_s'] for v in costs),peak_optimizer_RSS_KiB=max(v['process_peak_rss_kib'] for v in costs),matrix_wall_s=idx['elapsed_s'])
    dump(ROOT/'INDEPENDENT_COVERAGE_AND_BINDINGS.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('cell_vehicle_coverage_rows','failed_publications')}))
if __name__=='__main__':main()
