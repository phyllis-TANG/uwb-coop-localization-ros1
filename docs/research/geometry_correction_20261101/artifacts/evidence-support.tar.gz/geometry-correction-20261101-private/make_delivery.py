"""Private report/archive from the frozen experiment. No new estimator runs."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/work/uwb-geometry-correction-20261101')
BASE='b7af016b09e5717b718d9251341706fc33aa6f46'
FROZEN='63701fee9067d3517c4db9dde93a15891fc8335e'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def f(x):return f'{float(x):.9f}' if x is not None else 'NA'
def main():
    out=ROOT/'delivery';out.mkdir(exist_ok=True)
    a=ROOT/'analysis-v1';m=ROOT/'matrix-v1';doc=REPO/'docs/research/geometry_correction_20261101_private'
    idx=load(m/'RUN_INDEX.json');summary=load(a/'INTERACTION_SUMMARY.json');decision=load(a/'DECISION.json');masks=load(a/'COMMON_MASKS.json');audit=load(ROOT/'INDEPENDENT_COVERAGE_AND_BINDINGS.json');metric=load(ROOT/'METRIC_READBACK.json')
    assert idx['status']=='DONE' and len(idx['cells'])==48 and audit['status']==metric['status']=='PASS'
    for path in doc.iterdir():shutil.copy2(path,out/path.name)
    snapshot=out/'source_snapshot'
    for name in idx['source_sha256']:
        target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REPO/name,target)
    patch=subprocess.check_output(['git','diff','--binary',BASE,FROZEN],cwd=REPO)
    (out/'SOURCE.patch').write_bytes(patch)
    commitinfo=subprocess.check_output(['git','show','--no-patch','--format=fuller',FROZEN],cwd=REPO).decode()
    dump(out/'FREEZE_RECEIPT.json',dict(base_PR91_head=BASE,frozen_commit=FROZEN,protocol_sha256=sha(doc/'PROTOCOL.json'),protocol_in_frozen_git_object_sha256=hashlib.sha256(subprocess.check_output(['git','show',FROZEN+':docs/research/geometry_correction_20261101_private/PROTOCOL.json'],cwd=REPO)).hexdigest(),source_lock_sha256=sha(doc/'SOURCE_LOCK.json'),matrix_commit=idx['code_commit'],matrix_worktree_dirty=idx['worktree_dirty'],all_48_cell_commits_verified=True,git_commit_metadata=commitinfo,ordering='matrix refuses dirty tree before generating any study seed; all input generation and run commands are recorded in RUN_INDEX; metrics run only after48 DONE',preflight='dirty guard rejected an earlier launch before matrix/input creation; no optimizer cells executed in that rejected launch',post_result_changes='Only external environment inventory, coverage audit, report/plots/archive; frozen estimator, inputs and metric code unchanged.'))
    with (a/'PER_SEED_INTERACTIONS.csv').open() as h:contrasts=list(csv.DictReader(h))
    rows=[]
    for s in summary:
        vals=[r for r in contrasts if r['car']==s['car'] and r['method']==s['method']]
        rows.append([s['method'],s['car'],*[f(r['T_m2']) for r in vals],f(s['mean']),f"[{f(s['minimum'])}, {f(s['maximum'])}]",f"[{f(s['lo95'])}, {f(s['hi95'])}]",'通过' if s['pass_primary'] else '未通过'])
    ttable=table(['方法','车辆','701 T','702 T','703 T','704 T','均值','范围','95% t区间','固定规则'],rows)
    decomposition=[]
    for r in contrasts:
        decomposition.append([r['seed'],r['car'],r['method'],*[f(r[k]) for k in ('correction_M2_G1','correction_method_G1','C_G1','correction_M2_G2','correction_method_G2','C_G2','T_m2')]])
    dtable=table(['seed','车','方法','G1 ΔM2','G1 Δ方法','G1 C','G2 ΔM2','G2 Δ方法','G2 C','T'],decomposition)
    coverage=table(['seed','车','共同accepted/90','覆盖','主T可评估'],[[r['seed'],r['car'],f"{r['common_count']}/90",f"{100*r['common_coverage']:.2f}%",r['evaluable']] for r in masks])
    bymethod=[]
    for method in ('M2','M3','M3W025'):
        for car in ('car1','car2'):
            rs=[r for r in audit['cell_vehicle_coverage_rows'] if r['method']==method and r['car']==car]
            bymethod.append([method,car,len(rs),sum(r['scheduled'] for r in rs),sum(r['accepted'] for r in rs),sum(r['finite'] for r in rs),sum(r['failed'] for r in rs),sum(r['unknown_or_not_accepted'] for r in rs)])
    ctable=table(['方法','车','单元数','预定时刻','accepted','全有限','失败','unknown/未接受'],bymethod)
    failures=load(a/'FAILURES.json')
    verdict='通过' if decision['placement_alone_support'] else '未通过'
    direction='通过' if decision['field_direction_support'] else '未通过'
    text=f'''# 私有交付：摆位×Car2固定墙距校正交互

主判断：**{verdict}**。预定“方向与现场观察一致”判断：**{direction}**。仅按M3判断；W025是固定对照，不能替代主检验。此次试验完成后停止，没有追加种子、调整参数或重跑矩阵。

## 来源与冻结

- PR91实际采用head：`{BASE}`；未假定实时main等于该SHA。
- 新完整配置/执行/指标实现先本地提交：`{FROZEN}`。隔离分支`analysis/20261101-geometry-correction-private`。
- PROTOCOL.json SHA256：`{sha(doc/'PROTOCOL.json')}`。
- SOURCE_LOCK.json SHA256：`{sha(doc/'SOURCE_LOCK.json')}`。逐项锁{audit['source_files_locked']}个源文件，其中{audit['original_PR91_files_byte_identical']}个原有文件与PR91逐字节一致。
- `FREEZE_RECEIPT.json`记录Git对象、干净工作树和执行顺序。最初一次脏工作树预检在创建输入/矩阵目录之前拒绝启动，保留日志；不计为定位单元，没有作废后重跑的科学结果。
- 实际Python3.12.14 / NumPy2.2.6 / SciPy1.15.3，CPU、单BLAS/OMP线程；`ENVIRONMENT.json`记录实际加载路径，系统同名distribution不覆盖实际加载版本。

完整数值合同见PROTOCOL.json/PROTOCOL.md；16份真实运行config和输入hash在`matrix-v1/inputs/`。两处理都用各自前5秒观测重新拟合初始化，测得odom/gyro补偿运动后传播到t6；无真值初始化、无peer初始化、无odom角回退。前三帧warmup保留。初始化bias假设0，不读模拟真实bias。工程先验不等于已校准协方差。

G1原96秒both_moving；G2仅Car2真值全轨迹平移(+1.49,+2.01)m。墙锚、Car1、yaw、运动形状、杆臂、高度及内核均保持。Car2 node_10/node_2/node_3/node_8全程偏差为[.6088636184,.4497374906,.2012859605,.3685143909]m；historical仅从相同测量减去该向量。该已知向量是合成机制输入，不代表现场已知真实偏差。

## 交互结果

全部单位m²。D=MSE方法−MSE M2（负值为相对M2更小）；C=D historical−D raw；T=C G2−C G1。表中701–704指完整seed20261101701–20261101704。每车/seed所有12配置共用同一accepted/valid交集。

{ttable}

本次M3两车四个T都为负，均值区间均排除0且绝对均值超过.001m²，因此主判断通过。Car1要求的现场同向为正，本次却为负，所以进一步方向判断未通过。T描述的是两摆位之间“校正如何改变相对M2表现”的差异，不能直接读成绝对MSE的增减。Car2在G1中raw的M3相对M2优势很大，校正后该优势明显缩小；G2中这种优势缩小较少，因此Car2 T为负。Car1的M2校正改变只有约1e−18m²的数值舍入，M3的改变来自协同处理链。W025 Car1的符号不一致且区间跨0，反例完整保留。

Student-t区间按4个独立运行/seed、df=3计算；没有把90个时刻当独立重复。主规则是4个T同号、均值区间严格排除0、绝对均值≥.001m²且四seed均可评估。W025表中“固定规则”仅说明相同描述性条件，不改变其对照地位。每个D、C及精确T见`analysis-v1/PER_SEED_INTERACTIONS.csv`，每配置MSE见`PER_CONFIGURATION.csv`。

## 校正效应分解

Δ=MSE historical−MSE raw。C=Δ方法−ΔM2，T=(Δ方法G2−Δ方法G1)−(ΔM2G2−ΔM2G1)。负Δ表示该方法自身MSE下降。共同mask完全相同，因此分解是代数恒等式。

{dtable}

## 覆盖、失败与全有限输出

预定t6..95共90时刻，门槛72/90。所有12配置交集如下；没有按对比单独挑时刻。

{coverage}

{ctable}

共记录{len(failures)}个失败publication（每publication涉及双车；下表之外逐项在`analysis-v1/FAILURES.json`及原journal保留）。warmup/失败不从分母删去；全有限输出包含未接受预测，不能作为accepted替代。逐单元每车96行计数见`PER_CONFIGURATION.csv`和`INDEPENDENT_COVERAGE_AND_BINDINGS.json`。全有限误差/unknown在`ALL_FINITE_AND_UNKNOWN.jsonl.gz`，完整姿态和原始状态在各run的`published.csv`/`updates.jsonl.gz`；输入原语、输入/输出hash和全部命令均保留。

## 随机配对与独立读回

- 4个seed各只生成1份PR91顺序的15个随机数组，共{audit['pairing_random_arrays']}数组。wall/peer/odom/gyro/initial等字节hash固定，逐组同用；随摆位真实3D距离重算。
- 4份PAIRING均PASS，独立重放随机数，{audit['measurement_geometry_checks']}条墙/peer几何检查，{audit['pairing_initializers']}次车级初始化独立读回；Car1轨迹和初始化在四配置间相同。
- 48份原核目标/有限差分/QR prior/因果分箱读回均PASS：`{json.dumps(audit['readback_totals'],sort_keys=True)}`。这是数值完整性验收，不是监测器验收。
- 冻结的独立指标读回PASS：{metric['vehicle_CSV_publications']}条车级CSV publication，{metric['independent_scalar_checks']}个标量核对，8个共同mask；未导入在线求解器或主analyzer。
- 额外交付时覆盖/源字节/input-output绑定检查PASS；它只复核计数和字节，不改变冻结指标或决策。
- 总矩阵墙钟{audit['matrix_wall_s']:.2f}s（含生成及读回）；定位CPU总{audit['optimizer_cpu_s']:.2f}s；定位峰值RSS {audit['peak_optimizer_RSS_KiB']/1024:.2f}MiB。48个单元均DONE，未触发预设资源限额。

## 论断边界

结论只针对这两种摆位、完整轨迹、给定合成偏差、默认噪声、指定初始化和4个新seed。不能把W025替代M3作为主判断，也不能将接口PASS当作交互证据。4个seed的t区间及同号条件均只是预定的小样本数值规则；未作多重检验校正，不外推自然NLOS规律、线上检测、安全概率或实车动态精度。

前5秒重新初始化本身属于raw/historical处理的一部分；这里估计的是完整处理链的总交互，不能把全部差异都单独归因于稳态peer因子。固定窗QR prior仍可能带有历史。M2保持原独立目标及原联合失败发布政策。没有接通8维源排除监测，没有运行新监测器或自适应策略。实测A1/B1、A2/B2和停车点参考均未读取或改动。

## 产物与复现命令

根目录：`{ROOT}`；隔离源码：`{REPO}`。精确输入/输出hash见`matrix-v1/RUN_INDEX.json`，分析hash见`analysis-v1/ANALYSIS_INDEX.json`，全交付清单见`delivery/FULL_ARTIFACT_MANIFEST.json`。`SOURCE.patch`可在PR91精确base上审查应用，`source_snapshot/`包含全部锁定源码。原始结果不进入公开Git。

```bash
cd {REPO}
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
PY=/workspace/work/uwb-two-car-mechanism-20261101-run/venv/bin/python
# 以下是已执行命令；不再次执行48单元。matrix输出必须是不存在的新目录。
$PY tools/geometry_correction_20261101/matrix.py --output {m}
$PY tools/geometry_correction_20261101/analyze.py --matrix {m} --output {a}
$PY tools/geometry_correction_20261101/metric_readback.py --matrix {m} --analysis {a} --output {ROOT/'METRIC_READBACK.json'}
# 只读审查已有结果可打开CSV/JSON，或用新的readback输出路径执行上一行。
```

实际完整argv在RUN_INDEX.commands，stdout/stderr在`matrix-v1/logs/`及根`logs/`。未push、未创建PR、未公开上传研究材料。当前有限任务已完成，后续公开或扩展需另行授权。
'''
    (out/'HANDOFF.md').write_text(text)
    # A small standard scientific plot; all values are from the saved tables.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(9,3.6),sharey=False)
    for ax,car in zip(axes,('car1','car2')):
        for j,method in enumerate(('M3','M3W025')):
            vals=[float(r['T_m2']) for r in contrasts if r['car']==car and r['method']==method and r['T_m2']]
            s=next(r for r in summary if r['car']==car and r['method']==method)
            ax.scatter([j-.12+i*.08 for i in range(len(vals))],vals,s=24,color='C'+str(j),label=method+' seeds')
            if s['mean'] is not None:ax.errorbar([j+.25],[s['mean']],yerr=[[s['mean']-s['lo95']],[s['hi95']-s['mean']]],fmt='ks',capsize=4)
        ax.axhline(0,color='gray',lw=.8);ax.axhline(.001,color='gray',ls=':',lw=.8);ax.axhline(-.001,color='gray',ls=':',lw=.8)
        ax.set_xticks([0,1],['M3 (primary)','W025 (control)']);ax.set_title(car+' (own y scale)');ax.grid(axis='y',alpha=.2);ax.set_ylabel('Interaction T (m²)')
    fig.suptitle('Placement × Car2 correction: four seeds; mean and 95% t CI');fig.tight_layout();fig.savefig(out/'interaction.png',dpi=160);fig.savefig(out/'interaction.pdf');plt.close(fig)
    include=['matrix-v1','analysis-v1','delivery','logs','ENVIRONMENT.json','INDEPENDENT_COVERAGE_AND_BINDINGS.json','METRIC_READBACK.json','audit_delivery.py','make_delivery.py']
    files=[]
    for name in include:
        p=ROOT/name;files.extend(sorted(q for q in p.rglob('*') if q.is_file()) if p.is_dir() else [p])
    manifest=dict(files={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files if p!=out/'FULL_ARTIFACT_MANIFEST.json'},excluded_self='delivery/FULL_ARTIFACT_MANIFEST.json',public_upload=False)
    dump(out/'FULL_ARTIFACT_MANIFEST.json',manifest)
    archive=ROOT/'geometry-correction-20261101-private.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
        for name in include:tar.add(ROOT/name,arcname='geometry-correction-20261101-private/'+name)
    dump(ROOT/'DELIVERY_RECEIPT.json',dict(archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),full_manifest_sha256=sha(out/'FULL_ARTIFACT_MANIFEST.json'),handoff_sha256=sha(out/'HANDOFF.md'),matrix_index_sha256=sha(m/'RUN_INDEX.json'),analysis_index_sha256=sha(a/'ANALYSIS_INDEX.json'),metric_readback_sha256=sha(ROOT/'METRIC_READBACK.json'),publication='private workspace only; not uploaded'))
    print(json.dumps(load(ROOT/'DELIVERY_RECEIPT.json')))
if __name__=='__main__':main()
