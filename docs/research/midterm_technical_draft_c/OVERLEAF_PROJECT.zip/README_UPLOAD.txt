中文技术报告 Overleaf 上传包

上传整个ZIP作为New Project / Upload Project，主文件main.tex，编译器选择XeLaTeX。
本包包含完整可编辑LaTeX和所有正文图片；使用Noto Serif/Sans CJK SC及DejaVu字体。
已在本地以Tectonic 0.17.0编译同源文档，未实际登录或验证Overleaf远程环境。
技术正文20页，含封面/目录共23页。
如Overleaf环境缺少同名字体，需要安装字体或调整setmainfont/setCJKmainfont。
证据附件和Markdown编辑源在仓库docs/research/midterm_technical_draft_c/，不在此最小排版包内。
